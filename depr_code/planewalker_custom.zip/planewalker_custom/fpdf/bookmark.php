<?php
require('fpdf.php');

class PDF_Bookmark extends FPDF
{
	var $outlines=array();
	var $OutlineRoot;

	var $B;
	var $I;
	var $U;
	var $bi;
	var $HREF;
	var $CENTER=0;
	var $html;
	var $fontList;
	var $issetfont;
	var $issetcolor;

	function WriteHTML($html,$bi)
	{
		$this->bi = $bi;
		$this->CENTER=0;
		// change some win codes, and xhtml into html
		$str=array(
		'<br />' => '<br>',
		'<strong>' => '<b>',
		'</strong>' => '</b>',
		'<p style="text-align: center;">' => '<p><center>',
		'<p align="center">' => '<p><center>',
		'<p align=\'center\'>' => '<p><center>',
		'<p align=center>' => '<p><center>',
		'<hr />' => '<hr>',
		'[r]' => '<red>',
		'[/r]' => '</red>',
		'[l]' => '<blue>',
		'[/l]' => '</blue>',
		'&#8220;' => '"',
		'&#8221;' => '"',
		'&#8222;' => '"',
		'&#8230;' => '...',
		'&#8217;' => '\''
		);
		foreach ($str as $_from => $_to) $html = str_replace($_from,$_to,$html);
		
		//remove all unsupported tags
		if ($bi)
		{
				$html=strip_tags($html,"<a><img><p><br><font><tr><blockquote><h1><h2>".
										"<h3><h4><red><blue><ul><li><hr><b><i><u>".
										"<strong><center><em>");
		}
		else
		{
			$html=strip_tags($html,"<a><img><p><br><center><font><tr><blockquote><h1><h2><h3>".
									"<h4><red><blue><ul><li><hr>"); 
		}
		$html=str_replace("\n",' ',$html); //replace carriage returns by spaces

		$html = str_replace('&trade;','�',$html);
		$html = str_replace('&copy;','�',$html);
		$html = str_replace('&euro;','�',$html);

		$a=preg_split('/<(.*)>/U',$html,-1,PREG_SPLIT_DELIM_CAPTURE);
		$skip=false;
		foreach($a as $i=>$e)
		{
			if (!$skip) 
			{
				if($this->HREF)
					$e=str_replace("\n","",str_replace("\r","",$e));
				if($i%2==0)
				{
					// new line
					if($this->PRE)
						$e=str_replace("\r","\n",$e);
					else
						$e=str_replace("\r","",$e);
					//Text
					if($this->HREF)
					{
						$this->PutLink($this->HREF,$e);
						$skip=true;
					}
					else
					{
						$stuff = $e;
						$trans = get_html_translation_table(HTML_ENTITIES);
						$trans = array_flip($trans);
						$e = strtr($stuff, $trans);
						if($this->CENTER==1)
							$this->Cell(0,6,trim(stripslashes($e)),0,0,C);
						else
							$this->Write(6,trim(stripslashes($e)));
					}
				}
				else
				{
					//Tag
					if (substr(trim($e),0,1)=='/')
						$this->CloseTag(strtoupper(substr(trim($e),1)));
					else
					{
						//Extract attributes
						$a2=explode(' ',$e);
						$tag=strtoupper(array_shift($a2));
						$attr=array();
						foreach($a2 as $v) if(ereg('^([^=]*)=["\']?([^"\']*)["\']?$',$v,$a3)) 
						{
							$attr[strtoupper($a3[1])]=$a3[2];
						}
						$this->OpenTag($tag,$attr);
					}
				}
			}
			else
			{
				$this->HREF='';
				$skip=false;
			}
		}
	}

	function _hex2dec($color = "#000000")
	{
		$tbl_color = array();
		$tbl_color['R']=hexdec(substr($color, 1, 2));
		$tbl_color['G']=hexdec(substr($color, 3, 2));
		$tbl_color['B']=hexdec(substr($color, 5, 2));
		return $tbl_color;
	}

	function _px2mm($px)
	{
		return $px*25.4/72;
	}

	function _txtentities($html)
	{
		$trans = get_html_translation_table(HTML_ENTITIES);
		$trans = array_flip($trans);
		return strtr($html, $trans);
	}

	function _iso2ascii($s)
	{
		$iso="��������������������������ť��ة���ݮ����";
		$asc="acdeeillnorstuuyzaeouACDEEILLNORSTUUYZAEOU";
		return strtr($s,$iso,$asc);
	}

	function mySetTextColor($r,$g=0,$b=0)
	{
		static $_r=0, $_g=0, $_b=0;

		if ($r==-1) 
			$this->SetTextColor($_r,$_g,$_b);
		else 
		{
			$this->SetTextColor($r,$g,$b);
			$_r=$r;
			$_g=$g;
			$_b=$b;
		}
	}

	function PutLink($URL,$txt)
	{
		//Put a hyperlink
		$this->SetTextColor(0,0,255);
		$this->SetStyle('U',true);
		$this->Write(6,$txt,$URL);
		$this->SetStyle('U',false);
		$this->mySetTextColor(-1);
	}

	function PutLine()
	{
		$this->Ln(2);
		$this->Line($this->GetX(),$this->GetY(),$this->GetX()+187,$this->GetY());
		$this->Ln(3);
	}

	function OpenTag($tag,$attr)
	{
		//Opening tag
		switch($tag){
			case 'STRONG':
			case 'B':
				if ($this->bi)
					$this->SetStyle('B',true);
				else
					$this->SetStyle('U',true);
				break;
			case 'H1':
			//	$this->Ln(5);
				$this->SetTextColor(150,0,0);
				$this->SetFontSize(22);
				break;
			case 'H2':
			//	$this->Ln(5);
				$this->SetFontSize(18);
				$this->SetStyle('U',true);
				break;
			case 'H3':
			//	$this->Ln(5);
				$this->SetFontSize(16);
				$this->SetStyle('U',true);
				break;
			case 'H4':
			//	$this->Ln(5);
				$this->SetTextColor(102,0,0);
				$this->SetFontSize(14);
				if ($this->bi)
					$this->SetStyle('B',true);
				break;
			case 'PRE':
//				$this->SetFont('Courier','',11);
//				$this->SetFontSize(11);
//				$this->SetStyle('B',false);
//				$this->SetStyle('I',false);
//				$this->PRE=true;
				break;
			case 'RED':
				$this->SetTextColor(255,0,0);
				break;
			case 'BLOCKQUOTE':
				$this->mySetTextColor(100,0,45);
			//	$this->Ln(3);
				break;
			case 'BLUE':
				$this->SetTextColor(0,0,255);
				break;
			case 'I':
			case 'EM':
				if ($this->bi)
					$this->SetStyle('I',true);
				break;
			case 'U':
				$this->SetStyle('U',true);
				break;
			case 'A':
				$this->HREF=$attr['HREF'];
				break;
			case 'IMG':
				if(isset($attr['SRC']) and (isset($attr['WIDTH']) or isset($attr['HEIGHT']))) 
				{
					if(!isset($attr['WIDTH']))
						$attr['WIDTH'] = 0;
					if(!isset($attr['HEIGHT']))
						$attr['HEIGHT'] = 0;
					$this->Image($attr['SRC'], $this->GetX(), $this->GetY(),_px2mm($attr['WIDTH']), _px2mm($attr['HEIGHT']));
			//		$this->Ln(3);
				}
				break;
			case 'LI':
			//	$this->Ln(2);
				$this->SetTextColor(190,0,0);
				$this->Write(6,'     � ');
				$this->mySetTextColor(-1);
				break;
			case 'TR':
			//	$this->Ln(7);
				$this->PutLine();
				break;
			case 'BR':
				$this->Ln(6);
				break;
			case 'CENTER':
				$this->CENTER=1;
				break;
			case 'P':
				$this->Ln(6);
				$this->Ln(6);
			//	$this->Write(6,"");
				break;
			case 'HR':
				$this->PutLine();
				break;
			case 'FONT':
				if (isset($attr['COLOR']) and $attr['COLOR']!='') 
				{
					$coul=_hex2dec($attr['COLOR']);
					$this->mySetTextColor($coul['R'],$coul['G'],$coul['B']);
					$this->issetcolor=true;
				}
				if (isset($attr['FACE']) and in_array(strtolower($attr['FACE']), $this->fontlist))
				{
					$this->SetFont(strtolower($attr['FACE']));
					$this->issetfont=true;
				}
				break;
		}
	}

	function CloseTag($tag)
	{
		//Closing tag
		if ($tag=='H1' || $tag=='H2' || $tag=='H3' || $tag=='H4')
		{
//			$this->Ln(6);
//			$this->SetFont('Times','',12);
//			$this->SetFontSize(12);
			$this->SetStyle('U',false);
			$this->SetStyle('B',false);
			$this->mySetTextColor(-1);
		}
		if ($tag=='PRE')
		{
//			$this->SetFont('Times','',12);
//			$this->SetFontSize(12);
//			$this->PRE=false;
		}
		if	($tag == 'CENTER')
		{
			$this->CENTER=0;
		}
		if	($tag == 'P')
		{
			$this->CENTER=0;
		}
		if ($tag=='RED' || $tag=='BLUE')
			$this->mySetTextColor(-1);
		if ($tag=='BLOCKQUOTE')
		{
			$this->mySetTextColor(0,0,0);
		//	$this->Ln(3);
		}
		if($tag=='STRONG')
			$tag='B';
		if($tag=='EM')
			$tag='I';
		if((!$this->bi) && $tag=='B')
			$tag='U';
		if($tag=='B' or $tag=='I' or $tag=='U')
		{
			$this->SetStyle($tag,false);
		}
		if($tag=='A')
			$this->HREF='';
		if($tag=='FONT')
		{
			if ($this->issetcolor==true) 
			{
				$this->SetTextColor(0,0,0);
			}
			if ($this->issetfont) 
			{
//				$this->SetFont('Times','',12);
//				$this->issetfont=false;
			}
		}
	}

	function SetStyle($tag,$enable)
	{
//		$this->$tag+=($enable ? 1 : -1);
//		$style='';
//		foreach(array('B','I','U') as $s)
//			if($this->$s>0)
//				$style.=$s;
//		$this->SetFont('',$style);
		if($enable==true)
			$this->SetFont('',$tag);
		else
			$this->SetFont('','');
	}

	function Bookmark($txt,$level=0,$y=0)
	{
		if($y==-1)
			$y=$this->GetY();
		$this->outlines[]=array('t'=>$txt,'l'=>$level,'y'=>$y,'p'=>$this->PageNo());
	}

	function _putbookmarks()
	{
		$nb=count($this->outlines);
		if($nb==0)
			return;
		$lru=array();
		$level=0;
		foreach($this->outlines as $i=>$o)
		{
			if($o['l']>0)
			{
				$parent=$lru[$o['l']-1];
				//Set parent and last pointers
				$this->outlines[$i]['parent']=$parent;
				$this->outlines[$parent]['last']=$i;
				if($o['l']>$level)
				{
					//Level increasing: set first pointer
					$this->outlines[$parent]['first']=$i;
				}
			}
			else
				$this->outlines[$i]['parent']=$nb;
			if($o['l']<=$level and $i>0)
			{
				//Set prev and next pointers
				$prev=$lru[$o['l']];
				$this->outlines[$prev]['next']=$i;
				$this->outlines[$i]['prev']=$prev;
			}
			$lru[$o['l']]=$i;
			$level=$o['l'];
		}
		//Outline items
		$n=$this->n+1;
		foreach($this->outlines as $i=>$o)
		{
			$this->_newobj();
			$this->_out('<</Title '.$this->_textstring($o['t']));
			$this->_out('/Parent '.($n+$o['parent']).' 0 R');
			if(isset($o['prev']))
				$this->_out('/Prev '.($n+$o['prev']).' 0 R');
			if(isset($o['next']))
				$this->_out('/Next '.($n+$o['next']).' 0 R');
			if(isset($o['first']))
				$this->_out('/First '.($n+$o['first']).' 0 R');
			if(isset($o['last']))
				$this->_out('/Last '.($n+$o['last']).' 0 R');
			$this->_out(sprintf('/Dest [%d 0 R /XYZ 0 %.2f null]',1+2*$o['p'],($this->h-$o['y'])*$this->k));
			$this->_out('/Count 0>>');
			$this->_out('endobj');
		}
		//Outline root
		$this->_newobj();
		$this->OutlineRoot=$this->n;
		$this->_out('<</Type /Outlines /First '.$n.' 0 R');
		$this->_out('/Last '.($n+$lru[0]).' 0 R>>');
		$this->_out('endobj');
	}

	function _putresources()
	{
		parent::_putresources();
		$this->_putbookmarks();
	}

	function _putcatalog()
	{
		parent::_putcatalog();
		if(count($this->outlines)>0)
		{
			$this->_out('/Outlines '.$this->OutlineRoot.' 0 R');
			$this->_out('/PageMode /UseOutlines');
		}
	}
}
?>
