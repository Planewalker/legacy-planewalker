INTRODUCTION
Read data from Excel spread sheets without Microsoft!
Provides an API to allow any application to read Excel
documents. Written in PHP. Based on the the Java version by Andy Khan.

LINKS

OpenOffice.org's Documentation
http://sc.openoffice.org/excelfileformat.pdf

OLE2 Storage Documentation
http://jakarta.apache.org/poi/poifs/fileformat.html

Java API for reading, writing and modifying the contents of Excel spreadsheets
http://www.andykhan.com/

CONTACT
Vadim Tkachenko
vt@apachephp.com

INFO
For use encoding you must have installed iconv extension, otherwise data output in unicode

HOW TO USE
see example.php