<?
// **************************************************
// Name: index.php
// Author: edobrzel 08/18/2003 (based on "index.php" written by bast)
// Purpose: Main/home content page.
// Notes:
//	(none)
// Copyright � 2003 Planewalker.com. All Rights Reserved
// **************************************************
// Change History:
// MM/DD/YYYY User     Comment 
// ---------- -------- -------
// 02/01/2004 edobrzel Hooked up to dynamic section text code.
// **************************************************

define('cPathPrefix', '..');


function get_admin_menu(){
	$allowed_uids = array('1352', '1'); //1352 => <a href="viewPDF.php" target="_blank">, 1=>clueless
	$menu 	= '';
	
	$uid 	= $_COOKIE['db_drupal_uid'];
	$name 	= $_COOKIE['db_drupal_name'];
	
	if(in_array($uid, $allowed_uids)){
		$menu = '<div>Welcome, '.$name.'! Use the menu below to update the Gods List.</div>';
		$menu .= '<div align="center"> '.
					'<a href="index.php">View Gods</a> '.
					'| <a href="editGods.php">Edit Gods</a> '.
					'| <a href="editQualities.php">Edit Qualities</a> '.
					'| <a href="makeGodsListPDF.php">Remake Gods List PDF</a> '.
					'| <a href="upload.php">Upload File</a> '.
					'| <a href="viewPDF.php" target="_blank">View PDF</a> '.
					'</div><br><br>';		
	}
	return $menu;
}

function do_content()
{
	// **************************************************
	// * Name: do_content
	// * Purpose: Main content rederer.  Called by Layout.
	// * Output: [String] Returns content to be rendered.
	// **************************************************
	$cFunctionName = 'do_content';
	

	$mode = getRequest('mode');
	if(strlen($mode)==0)
		$mode = "source";
	// Mode could also be:
	// rank
	// asset
	// alignment

	$submitAsset = getRequest('submitAsset');
	if(strlen($submitAsset)>0)
	{
		$intAssetID = getRequest('intAssetID');
		$strAssetName = getRequest('strAssetName');
		$found = editGLAsset($intAssetID, $strAssetName);
	}
	
	$deleteAsset = getRequest('deleteAsset');
	if(strlen($deleteAsset)>0)
	{
		$intAssetID = getRequest('intAssetID');
		deleteGLAsset($intAssetID);
	}	
	
	$submitRank = getRequest('submitRank');
	if(strlen($submitRank)>0)
	{
		$intRankID = getRequest('intRankID');
		$strRankName = getRequest('strRankName');
		$found = editGLRank($intRankID, $strRankName);
	}

	$deleteRank = getRequest('deleteRank');
	if(strlen($deleteRank)>0)
	{
		$intRankID = getRequest('intRankID');
		deleteGLRank($intRankID);
	}
	
	$submitAlignment = getRequest('submitAlignment');
	if(strlen($submitAlignment)>0)
	{
		$intAlignmentID = getRequest('intAlignmentID');
		$strAlignmentName = getRequest('strAlignmentName');
		$found = editGLAlignment($intAlignmentID, $strAlignmentName);
	}

	$deleteAlignment = getRequest('deleteAlignment');
	if(strlen($deleteAlignment)>0)
	{
 		$intAlignmentID = getRequest('intAlignmentID');
		deleteGLAlignment($intAlignmentID);
	}
	
	$submitSource = getRequest('submitSource');
	if(strlen($submitSource)>0)
	{
		$intSourceID = getRequest('intSourceID');
		$strSourceName = getRequest('strSourceName');
		$strSourceURL = getRequest('strSourceURL');
		$dtmSourceDate = toDateTimestamp(getRequest('dtmSourceDate'));
		if(strlen($dtmSourceDate)==0)
			$dtmSourceDate = toDateTimestamp(time());
		$found = editGLSource($intSourceID, $strSourceName, $strSourceURL, $dtmSourceDate);
	}
	
	$deleteSource = getRequest('deleteSource');
	if(strlen($deleteSource)>0)
	{
		$intSourceID = getRequest('intSourceID');
		deleteGLSource($intSourceID);
	}

	$strRet .= "<div align=center>Choose your mode: <a href='editQualities.php?mode=rank'>rank</a> | <a href='editQualities.php?mode=asset'>asset</a> | <a href='editQualities.php?mode=alignment'>alignment</a> | <a href='editQualities.php?mode=source'>source</a></div><br><br>";

	if($mode=="rank")
	{
			$strRet .=showRankSelection($mode);
	}

	if($mode=="asset")
	{
			$strRet .=showAssetSelection($mode);
	}

	if($mode=="alignment")
	{
			$strRet .=showAlignmentSelection($mode);
	}

	if($mode=="source")
	{
			$strRet .=showSourceSelection($mode);
	}
	return get_admin_menu().$strRet;

}

function showRankSelection($mode)
{
	$ranks = getGLRanks();
	$strRet .= "<table cellspacing=0>";
	$strRet .= "	<tr>
			<td>Rank Name</td>
			</tr>";
	$count = 0;
	while($val = mysql_fetch_assoc($ranks))
	{
		$intRankID		= $val[intRankID];
		$strRankName	= $val[strRankName];

		if ($count % 2 > 0)
			$strCSS = "TableRowOdd";
		else
			$strCSS = "TableRowEven";
		$strRet .= "<tr class='".$strCSS."'>";
		$strRet .= "<form method=post action=''>";
		$strRet .= drawHidden('intRankID', $intRankID);
		$strRet .= drawHidden('mode', $mode);
		$strRet .= "<tr class='".$strCSS."'><td colspan=2></tr>";
		$strRet .= "<td>".drawText('strRankName', $strRankName, 50)."</td>";
		$strRet .= "</tr><tr class='".$strCSS."'>";
		$strRet .= "<td>["
					.drawSubmit('submitRank', 'Edit Rank', submitLink)."] ["
					.drawSubmit('deleteRank', 'Delete Rank', submitLink)."]"
				."</td>";
		$strRet .= "</form>";
		$strRet .= "</tr>";
		$count++;
	}
	$strRet .= "</table>";
	return $strRet;
}

function showAssetSelection($mode)
{
	$assets = getGLAssets();
	$strRet .= "<table cellspacing=0>";
	$strRet .= "	<tr>
			<td>Asset Name</td>
			</tr>";
	$count = 0;
	while($val = mysql_fetch_assoc($assets))
	{
		$intAssetID	= $val[intAssetID];
		$strAssetName	= $val[strAssetName];

		if ($count % 2 > 0)
			$strCSS = "TableRowOdd";
		else
			$strCSS = "TableRowEven";
		$strRet .= "<tr class='".$strCSS."'>";
		$strRet .= "<form method=post action=''>";
		$strRet .= drawHidden('intAssetID', $intAssetID);
		$strRet .= drawHidden('mode', $mode);
		$strRet .= "<tr class='".$strCSS."'><td colspan=2></tr>";
		$strRet .= "<td>".drawText('strAssetName', $strAssetName, 50)."</td>";
		$strRet .= "</tr><tr class='".$strCSS."'>";
		$strRet .= "<td>["
					.drawSubmit('submitAsset', 'Edit Asset', submitLink)."] ["
					.drawSubmit('deleteAsset', 'Delete Asset', submitLink)."]"
				."</td>";
		$strRet .= "</form>";
		$strRet .= "</tr>";
		$count++;
	}
	$strRet .= "</table>";
	return $strRet;
}

function showAlignmentSelection($mode)
{
	$alignments = getGLAlignments();
	$strRet .= "<table cellspacing=0>";
	$strRet .= "	<tr>
			<td>Alignment Name</td>
			</tr>";
	$count = 0;
	while($val = mysql_fetch_assoc($alignments))
	{
		$intAlignmentID		= $val[intAlignmentID];
		$strAlignmentName	= $val[strAlignmentName];

		if ($count % 2 > 0)
			$strCSS = "TableRowOdd";
		else
			$strCSS = "TableRowEven";
		$strRet .= "<tr class='".$strCSS."'>";
		$strRet .= "<form method=post action=''>";
		$strRet .= drawHidden('intAlignmentID', $intAlignmentID);
		$strRet .= drawHidden('mode', $mode);
		$strRet .= "<tr class='".$strCSS."'><td colspan=2></tr>";
		$strRet .= "<td>".drawText('strAlignmentName', $strAlignmentName, 50)."</td>";
		$strRet .= "</tr><tr class='".$strCSS."'>";
		$strRet .= "<td>["
					.drawSubmit('submitAlignment', 'Edit Alignment', submitLink)."] ["
					.drawSubmit('deleteAlignment', 'Delete Alignment', submitLink)."]"
				."</td>";
		$strRet .= "</form>";
		$strRet .= "</tr>";
		$count++;
	}
	$strRet .= "</table>";
	return $strRet;
}

function showSourceSelection($mode)
{
	$sources = getGLSources();
	$strRet .= "<table cellspacing=0>";
	$strRet .= "	<tr>
			<td>Source Name</td>
			<td>Date Published</td>
			</tr>";
	$count = 0;
	while($val = mysql_fetch_assoc($sources))
	{
		$intSourceID	= $val[intSourceID];
		$strSourceName	= $val[strSourceName];
		$intSourceURL	= $val[intSourceURL];
		$dtmSourceDate	= $val[dtmSourceDate];

		if ($count % 2 > 0)
			$strCSS = "TableRowOdd";
		else
			$strCSS = "TableRowEven";
		$strRet .= "<tr class='".$strCSS."'>";
		$strRet .= "<form method=post action=''>";
		$strRet .= drawHidden('intSourceID', $intSourceID);
		$strRet .= drawHidden('strSourceURL', '');
		$strRet .= drawHidden('mode', $mode);
		$strRet .= "<tr class='".$strCSS."'><td colspan=2></tr>";
		$strRet .= "<td>".drawText('strSourceName', $strSourceName, 50)."</td>";
		$strRet .= "<td>".drawText('dtmSourceDate', formatDate($dtmSourceDate, 1), 30)."</td>";
		$strRet .= "</tr><tr class='".$strCSS."'>";
		$strRet .= "<td colspan=2>["
					.drawSubmit('submitSource', 'Edit Source', submitLink)."] ["
					.drawSubmit('deleteSource', 'Delete Source', submitLink)."]"
				."</td>";
		$strRet .= "</form>";
		$strRet .= "</tr>";
		$count++;
	}
	$strRet .= "</table>";
	return '<html><body style="background:#EEEEE7;">'.$strRet.'</body></html>';
}
// OUTPUT WEBPAGE	-----------------------------
include(cPathPrefix . '/layout_invis.php');
?>