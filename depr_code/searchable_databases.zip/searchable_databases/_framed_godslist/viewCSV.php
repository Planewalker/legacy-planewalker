<?
// **************************************************
// Name: index.php
// Author: edobrzel 08/18/2003 (based on "index.php" written by bast)
// Purpose: Main/home content page.
// Notes:
//    (none)
// Copyright � 2003 Planewalker.com. All Rights Reserved
// **************************************************
// Change History:
// MM/DD/YYYY User     Comment 
// ---------- -------- -------
// 02/01/2004 edobrzel Hooked up to dynamic section text code.
// 08/09/2009 shood Fix up PDF link error
// **************************************************

define('cPathPrefix', '..');

$extraFiles = array("/DB_GodsList.php");


function get_admin_menu(){
    $allowed_uids = array('1352', '1'); //1352 => alzrius, 1=>clueless
    $menu     = '';
    
    $uid     = $_COOKIE['db_drupal_uid'];
    $name     = $_COOKIE['db_drupal_name'];
    
    if(in_array($uid, $allowed_uids)){
        $menu = '<div>Welcome, '.$name.'! Use the menu below to update the Gods List.</div>';
        $menu .= '<div align="center"> '.
                    '<a href="index.php">View Gods</a> '.
                    '| <a href="editGods.php">Edit Gods</a> '.
                    '| <a href="editQualities.php">Edit Qualities</a> '.
                    '| <a href="makeGodsListPDF.php">Remake Gods List PDF</a> '.
                    '| <a href="upload.php">Upload File</a> '.
                    '| <a href="viewPDF.php" target="_blank">View PDF</a> '.
                    '</div><br><br>';        
    }
    return $menu;
}

function do_content()
{
    // **************************************************
    // * Name: do_content
    // * Purpose: Main content rederer.  Called by Layout.
    // * Output: [String] Returns content to be rendered.
    // **************************************************
    $cFunctionName = 'do_content';
           
    $keys = $_SESSION[godListKeys];
    $gods = searchGLGodsList($keys, "AND");
  		// As CSV Text file
		header("Content-Type: application/text");
		header("Expires: 0");
		header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
		header("Content-Disposition: attachment;filename=GODSLIST.csv");
		$retStr .= "";
		
    while($g = mysql_fetch_assoc($gods))
    {
        $first = substr($g[strName],0,1);
        $retStr .= '"'.$g[strName].'",';
            
        $rString = "";
        $ranks = getGLGodsRanks($g[intGodID]);
        $first = 0;
        while($r = mysql_fetch_assoc($ranks))
        {
            if($first==0)
            {
                $first=1;
                $rString .= $r[strRankName]."";
            }
            else
                $rString .= ", ".$r[strRankName]."";
        }
        $rString = str_replace('"', '', $rString);
        $retStr .= '"'.$rString.'",';   
                    
        $alString = "";
        $alignments = getGLGodsAlignments($g[intGodID]);
        $first = 0;
        while($al = mysql_fetch_assoc($alignments))
        {
            if($first==0)
            {
                $first=1;
                $alString .= $al[strAlignmentName]."";
            }
            else
                $alString .= ", ".$al[strAlignmentName]."";
        }
        $alString = str_replace('"', '', $alString);
        $retStr .= '"'.$alString.'",';          
                    
        $asString = "";
        $assets = getGLGodsAssets($g[intGodID]);
        $first = 0;
        while($as = mysql_fetch_assoc($assets))
        {
            if($first==0)
            {
                $first=1;
                $asString .= $as[strAssetName]."";
            }
            else
                $asString .= ", ".$as[strAssetName]."";
        }
        $asString = str_replace('"', '', $asString); 
        $retStr .= '"'.$asString.'",';         
        
        $sString = "";
        $urlString = "";
        $sources = getGLGodsSources($g[intGodID]);
        $first = 0;
        while($s = mysql_fetch_assoc($sources))
        {
            if($first==0)
            {
                $first=1;
                if(strlen($s[strSourceURL])>0)
                    $sString .= $s[strSourceName]." (".$s[strSourceURL].")";
                else
                    $sString .= $s[strSourceName]."";    
            }
            else
            {
                if(strlen($s[strSourceURL])>0)
                    $sString .= ", ".$s[strSourceName]." (".$s[strSourceURL].")";
                else
                    $sString .= ", ".$s[strSourceName]."";    
            }
        }
        $sString = str_replace('"', '', $sString);
        $retStr .= '"'.$sString.'",';      
		  $retStr .= "\n";     
    }    
	return $retStr;
}

// OUTPUT WEBPAGE    -----------------------------
include(cPathPrefix . '/layout_invis.php');
?>