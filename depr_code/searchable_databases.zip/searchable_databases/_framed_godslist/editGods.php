<?
// **************************************************
// Name: index.php
// Author: edobrzel 08/18/2003 (based on "index.php" written by bast)
// Purpose: Main/home content page.
// Notes:
//	(none)
// Copyright � 2003 Planewalker.com. All Rights Reserved
// **************************************************
// Change History:
// MM/DD/YYYY User     Comment 
// ---------- -------- -------
// 02/01/2004 edobrzel Hooked up to dynamic section text code.
// **************************************************
define('cPathPrefix', '..');
$extraFiles = array("/DB_GodsList.php");

function get_admin_menu(){
	$allowed_uids = array('1352', '1'); //1352 => alzrius, 1=>clueless
	$menu 	= '';
	
	$uid 	= $_COOKIE['db_drupal_uid'];
	$name 	= $_COOKIE['db_drupal_name'];
	
	if(in_array($uid, $allowed_uids)){
		$menu = '<div>Welcome, '.$name.'! Use the menu below to update the Gods List.</div>';
		$menu .= '<div align="center"> '.
					'<a href="index.php">View Gods</a> '.
					'| <a href="editGods.php">Edit Gods</a> '.
					'| <a href="editQualities.php">Edit Qualities</a> '.
					'| <a href="makeGodsListPDF.php">Remake Gods List PDF</a> '.
					'| <a href="upload.php">Upload File</a> '.
					'| <a href="viewPDF.php" target="_blank">View PDF</a> '.
					'</div><br><br>';		
	}
	return $menu;
}

function do_content()
{
	// **************************************************
	// * Name: do_content
	// * Purpose: Main content rederer.  Called by Layout.
	// * Output: [String] Returns content to be rendered.
	// **************************************************
	$cFunctionName = 'do_content';
	

	$allowed_uids = array('1352', '1'); //1352 => alzrius, 1=>clueless
	$uid 	= $_COOKIE['db_drupal_uid'];
	$name 	= $_COOKIE['db_drupal_name'];
	if(!in_array($uid, $allowed_uids)){
		header('Location:index.php');
		exit;
	}	
	
	$intGodID = getRequest('intGodID');
	if(strlen($intGodID)==0)
		$intGodID=-1;
		
	$submitGod = getRequest('submitGod');		// A value checked for *all* submissions of entry.
	if(strlen($submitGod)>0)					// Additions, and subtractions included.
	{
		// Handle submission
		$intGodID = getRequest('intGodID');
		$strName = getRequest('strName');
		$intGodID = editGLGod($intGodID, $strName);
		// Newly created god should be SET BY THIS POINT.
		// Editted god remains set to the same value.
		// This allows any editting below this point to 
		// confidently use $intGodID
		$done = getRequest('submitDone');
		if(strlen($done)>0)
			header('Location:index.php');

			// Handle submission
			if($intGodID!=-1)
			{
				$strAssetName = getRequest('strAssetName');
				if(strlen($strAssetName)>0)
				{
					$found = searchGLAsset($strAssetName);
					if($found = mysql_fetch_assoc($found))
						glueGLGodToAsset($intGodID, $found[intAssetID]);
					else
					{
						$found = editGLAsset(-1, $strAssetName);
						glueGLGodToAsset($intGodID, $found);
					}
				}
				
				$intAssetID = getRequest('intAssetID');
				if(strlen($intAssetID)>0)
					glueGLGodToAsset($intGodID, $intAssetID);
			}		
		
			// Handle submission
			if($intGodID!=-1)
			{
				$strRankName = getRequest('strRankName');
				if(strlen($strRankName)>0)
				{
					$found = searchGLRank($strRankName);
					if($found = mysql_fetch_assoc($found))
						glueGLGodToRank($intGodID, $found[intRankID]);
					else
					{
						$found = editRank(-1, $strRankName);
						glueGLGodToRank($intGodID, $found);
					}
				}
				$intRankID = getRequest('intRankID');
				if(strlen($intRankID)>0)
					glueGLGodToRank($intGodID, $intRankID);
			}

			// Handle submission
			if($intGodID!=-1)
			{
				$strAlignmentName = getRequest('strAlignmentName');
				if(strlen($strAlignmentName)>0)
				{
					$found = searchGLAlignment($strAlignmentName);
					if($found = mysql_fetch_assoc($found))
						glueGLGodToAlignment($intGodID, $found[intAlignmentID]);
					else
					{
						$found = editGLAlignment(-1, $strAlignmentName);
						glueGLGodToAlignment($intGodID, $found);
					}
				}
				$intAlignmentID = getRequest('intAlignmentID');
				if(strlen($intAlignmentID)>0)
					glueGLGodToAlignment($intGodID, $intAlignmentID);
			}
		
			// Handle submission
			if($intGodID!=-1)
			{
				$strSourceName = getRequest('strSourceName');
				if(strlen($strSourceName)>0)
				{
					$found = searchGLSource($strSourceName);
					if($found = mysql_fetch_assoc($found))
						glueGLGodToSource($intGodID, $found[intID]);
					else
					{
						$strSourceURL = getRequest('strSourceURL');
						$dtmSourceDate = toDateTimestamp(getRequest('dtmSourceDate'));
						if(strlen($dtmSourceDate)==0)
							$dtmSourceDate = toDateTimestamp(time());
						$found = editGLSource(-1, $strSourceName, $strSourceURL, $dtmSourceDate);
						glueGLGodToSource($intGodID, $found);
					}
				}
				$intSourceID = getRequest('intSourceID');
				if(strlen($intSourceID)>0)
					glueGLGodToSource($intGodID, $intSourceID);
			}
	}

	$deleteGod = getRequest('deleteGod');
	if(strlen($deleteGod)>0)
	{
		$intGodID = getRequest('intGodID');
		$g = getGLGod($intGodID);
		$g = mysql_fetch_assoc($g);
		$strRet .= "<div align=center><b>Are you sure?</b></div>";
		$strRet .= "<hr>";
		$strRet .= displayGLGod($g);
		$strRet .= "<hr>";
		$strRet .= "<div align=center>";
		$strRet .= "<form method=post action=''>".
				drawSubmit(deleteConfirm, 'Yes. Delete this God.').
				drawHidden(intGodID, $intGodID).
				"</form>";
		$strRet .= "</div>";
	}

	$deleteConfirm = getRequest('deleteConfirm');
	if(strlen($deleteConfirm)>0)
	{
		$intGodID = getRequest('intGodID');
		deleteGLGod($intGodID);
	}

	$submitAsset = getRequest('submitAsset');
	if(strlen($submitAsset)>0)
	{
		// Handle submission
		if($intGodID!=-1)
		{
			$strAssetName = getRequest('strAssetName');
			if(strlen($strAssetName)>0)
			{
				$found = searchGLAsset($strAssetName);
				if($f = mysql_fetch_assoc($found))
					glueGLGodToAsset($intGodID, $f[intAssetID]);
				else
				{
					$found = editGLAsset(-1, $strAssetName);
					glueGLGodToAsset($intGodID, $found);
				}
			}
			
			$intAssetID = getRequest('intAssetID');
			if(strlen($intAssetID)>0)
				glueGLGodToAsset($intGodID, $intAssetID);
		}		
	}
	
	$deleteAsset = getRequest('deleteAsset');
	if(strlen($deleteAsset)>0)
	{
		// Handle submission
		if($intGodID!=-1)
		{
			$intAssetIDs = getRequest('intAssetIDs');
			for($i=0;$i<count($intAssetIDs);$i++)
			{
				unglueGLGodToAsset($intGodID, $intAssetIDs[$i]);
//				unglueGLGodToAsset($intGodID, $intAssetIDs);
			}
		}
	}	
	
	$submitRank = getRequest('submitRank');
	if(strlen($submitRank)>0)
	{
		// Handle submission
		if($intGodID!=-1)
		{
			$strRankName = getRequest('strRankName');
			if(strlen($strRankName)>0)
			{
				$found = searchGLRank($strRankName);
				if($f = mysql_fetch_assoc($found))
					glueGLGodToRank($intGodID, $f[intRankID]);
				else
				{
					$found = editGLRank(-1, $strRankName);
					glueGLGodToRank($intGodID, $found);
				}
			}
			$intRankID = getRequest('intRankID');
			if(strlen($intRankID)>0)
				glueGLGodToRank($intGodID, $intRankID);
		}
	}

	$deleteRank = getRequest('deleteRank');
	if(strlen($deleteRank)>0)
	{
		// Handle submission
		if($intGodID!=-1)
		{
			$intRankIDs = getRequest('intRankIDs');
			for($i=0;$i<count($intRankIDs);$i++)
			{
				unglueGLGodToRank($intGodID, $intRankIDs[$i]);
//				unglueGLGodToRank($intGodID, $intRankIDs);
			}		
		}
	}
	
	$submitAlignment = getRequest('submitAlignment');
	if(strlen($submitAlignment)>0)
	{
		// Handle submission
		if($intGodID!=-1)
		{
			$strAlignmentName = getRequest('strAlignmentName');
			if(strlen($strAlignmentName)>0)
			{
				$found = searchGLAlignment($strAlignmentName);
				if($f = mysql_fetch_assoc($found))
					glueGLGodToAlignment($intGodID, $f[intAlignmentID]);
				else
				{
					$found = editGLAlignment(-1, $strAlignmentName);
					glueGLGodToAlignment($intGodID, $found);
				}
			}
			$intAlignmentID = getRequest('intAlignmentID');
			if(strlen($intAlignmentID)>0)
				glueGLGodToAlignment($intGodID, $intAlignmentID);
		}
	}

	$deleteAlignment = getRequest('deleteAlignment');
	if(strlen($deleteAlignment)>0)
	{
		// Handle submission
		if($intGodID!=-1)
		{
			$intAlignmentIDs = getRequest('intAlignmentIDs');
			for($i=0;$i<count($intAlignmentIDs);$i++)
			{
				unglueGLGodToAlignment($intGodID, $intAlignmentIDs[$i]);
//				unglueGLGodToAlignment($intGodID, $intAlignmentIDs);
			}		
		}
	}
	
	$submitSource = getRequest('submitSource');
	if(strlen($submitSource)>0)
	{
		// Handle submission
		if($intGodID!=-1)
		{
			$strSourceName = getRequest('strSourceName');
			if(strlen($strSourceName)>0)
			{
				$found = searchGLSource($strSourceName);
				if($f = mysql_fetch_assoc($found))
					glueGLGodToSource($intGodID, $f[intSourceID]);
				else
				{
					$strSourceURL = getRequest('strSourceURL');
					$dtmSourceDate = toDateTimestamp(getRequest('dtmSourceDate'));
					if(strlen($dtmSourceDate)==0)
						$dtmSourceDate = toDateTimestamp(time());
					$found = editGLSource(-1, $strSourceName, $strSourceURL, $dtmSourceDate);
					glueGLGodToSource($intGodID, $found);
				}
			}
			$intSourceID = getRequest('intSourceID');
			if(strlen($intSourceID)>0)
				glueGLGodToSource($intGodID, $intSourceID);
		}
	}
	
	$deleteSource = getRequest('deleteSource');
	if(strlen($deleteSource)>0)
	{
		// Handle submission
		if($intGodID!=-1)
		{
			$intSourceIDs = getRequest('intSourceIDs');
			for($i=0;$i<count($intSourceIDs);$i++)
			{
				unglueGLGodToSource($intGodID, $intSourceIDs[$i]);
			}				
		}
	}
	
	if($intGodID!=-1)
	{
		// Set already existing values.
		$god = getGLGod($intGodID);
		if($god = mysql_fetch_assoc($god))
		{
			$strName = $god[strName];

			$godAssets 		= getGLGodsAssets($intGodID);
			$assets 		= array();
			$assetIds 		= array();
			while($val = mysql_fetch_assoc($godAssets))
			{
				array_push($assets, 		$val[strAssetName]);
				array_push($assetIds, 		$val[intAssetID]);
			}
			
			$godRanks 		= getGLGodsRanks($intGodID);
			$ranks			= array();
			$rankIds		= array();
			while($val = mysql_fetch_assoc($godRanks))
			{
				array_push($ranks, 			$val[strRankName]);
				array_push($rankIds, 		$val[intRankID]);
			}
						
			$godAlignments 	= getGLGodsAlignments($intGodID);
			$alignments		= array();
			$alignmentIds 	= array();
			while($val = mysql_fetch_assoc($godAlignments))
			{
				array_push($alignments, 		$val[strAlignmentName]);
				array_push($alignmentIds, 		$val[intAlignmentID]);
			}
						
			$godSources 	= getGLGodsSources($intGodID);
			$sources		= array();
			$sourceURLs		= array();
			$sourceDates	= array();
			$sourceIds		= array();
			while($val = mysql_fetch_assoc($godSources))
			{
				array_push($sources, 		$val[strSourceName]);
				array_push($sourceURLs,	 	$val[intSourceURL]);
				array_push($sourceDates,	$val[sourceDate]);
				array_push($sourceIds,	 	$val[intSourceID]);
			}
		}
		else
			$intGodID=-1;	// No god found, set to default.
	}
	
	// $strRet .= the form.

	$strRet .= "	
	<form method=post action=''>
	".drawHidden('intGodID', $intGodID)."
	".drawHidden('submitGod', 1)."	
	<table>
	<tr>
		<td colspan=3>God Name:</td>
	</tr>
	<tr>
		<td width=20px></td>
		<td colspan=2>".drawText('strName', $strName, 50)."</td>
	</tr>
	<tr>
		<td colspan=3>Portfolio:</td>
	</tr>
	<tr>
		<td></td>
		<td colspan=2>".dropdownAsset()."</td>
	</tr>
	<tr>
		<td></td>
		<td>".drawText('strAssetName', '', 50)."</td>		
		<td>".drawSubmit('submitAsset', 'Add Portfolio')."</td>		
	</tr>
	<tr>
		<td></td>
		<td colspan=2>".listAssets($assets, $assetIds)."</td>
	</tr>
	<tr>
		<td colspan=3>Rank:</td>
	</tr>
	<tr>
		<td></td>
		<td colspan=2>".dropdownRank()."</td>
	</tr>
	<tr>
		<td></td>
		<td>".drawText('strRankName', '', 50)."</td>		
		<td>".drawSubmit('submitRank', 'Add Rank')."</td>		
	</tr>
	<tr>
		<td></td>
		<td colspan=2>".listRanks($ranks, $rankIds)."</td>
	</tr>
	<tr>
		<td colspan=3>Alignment:</td>
	</tr>
	<tr>
		<td></td>
		<td colspan=2>".dropdownAlignment()."</td>
	</tr>
	<tr>
		<td></td>
		<td>".drawText('strAlignmentName', '', 50)."</td>		
		<td>".drawSubmit('submitAlignment', 'Add Alignment')."</td>		
	</tr>
	<tr>
		<td></td>
		<td colspan=2>".listAlignments($alignments, $alignmentIds)."</td>
	</tr>
	<tr>
		<td colspan=3>Sources:</td>
	</tr>
	<tr>
		<td></td>
		<td colspan=2>".dropdownSource()."</td>
	</tr>
	<tr>
		<td></td>
		<td>
			".drawText('strSourceName', '', 50)."
			".drawHidden('strSourceURL', '')."
		</td>
	</tr>
	<tr>
		<td></td>
		<td>
			Date Published:".drawText('dtmSourceDate', '', 50)."
		</td>
		<td>".drawSubmit('submitSource', 'Add Source')."</td>
	</tr>
	<tr>
		<td></td>
		<td colspan=2>".listSources($sources, $sourceURLs, $sourceIds)."</td>
	</tr>
	<tr>
		<td colspan=3>".drawSubmit('submitEdit', 'Edit').
			drawSubmit('submitDone', 'Done').
			drawSubmit('deleteGod', 'Delete God').
			"</td>
	</tr>	
	</table>
	</form>";
	return get_admin_menu().$strRet;
	
}

function dropdownAsset()
{
	$cFuncName = "dropdownAsset";
	$Asset = getGLAssets();
	$strRet = "<select name=intAssetID style='width:300px'>\n";
	$strRet .= "<option value=-1 SELECTED></option>";
	while($drop = mysql_fetch_assoc($Asset))
	{
		$strRet .= "<option value=".$drop[intAssetID].">".$drop[strAssetName]."</option>\n";
	}
	$strRet .= "</select>\n";
	return $strRet;
}

function dropdownRank()
{
	$cFuncName = "dropdownRank";
	$Rank= getGLRanks();
	$strRet = "<select name=intRankID style='width:300px'>\n";
	$strRet .= "<option value=-1 SELECTED></option>";
	while($drop = mysql_fetch_assoc($Rank))
	{
		$strRet .= "<option value=".$drop[intRankID].">".$drop[strRankName]."</option>\n";
	}
	$strRet .= "</select>\n";
	return $strRet;
}

function dropdownAlignment()
{
	$cFuncName = "dropdownAlignment";
	$Alignment= getGLAlignments();
	$strRet = "<select name=intAlignmentID style='width:300px'>\n";
	$strRet .= "<option value=-1 SELECTED></option>";	
	while($drop = mysql_fetch_assoc($Alignment))
	{
		$strRet .= "<option value=".$drop[intAlignmentID].">".$drop[strAlignmentName]."</option>\n";
	}
	$strRet .= "</select>\n";
	return $strRet;
}

function dropdownSource()
{
	$cFuncName = "dropdownSource";
	$Source= getGLSources();
	$strRet = "<select name=intSourceID style='width:300px'>\n";
	$strRet .= "<option value=-1 SELECTED></option>";
	while($drop = mysql_fetch_assoc($Source))
	{
		$strRet .= "<option value=".$drop[intSourceID].">".$drop[strSourceName]."</option>\n";
	}
	$strRet .= "</select>\n";
	return $strRet;
}

function listAssets($assets, $ids)
{
	$strRet = "<table>\n";
	for($i=0;$i<count($assets);$i++)
	{
//		$strRet .= "<tr><td>".drawSingleCheckbox('intAssetIDs[]', $assets[$i], $ids[$i])."</td></tr>\n";
		$strRet .= "<tr><td>".drawSingleCheckbox('intAssetIDs[]', $ids[$i], $assets[$i])."</td></tr>\n";
	}
	$strRet .= "<tr><td colspan=2>".drawSubmit('deleteAsset', 'Remove Selected')."</td></tr>\n";
	$strRet .= "</table>\n";
	return $strRet;
}

function listRanks($ranks, $ids)
{
	$strRet = "<table>\n";
	for($i=0;$i<count($ranks);$i++)
	{
//		$strRet .= "<tr><td>".drawSingleCheckbox('intRankIDs[]', $ranks[$i], $ids[$i])."</td></tr>\n";
		$strRet .= "<tr><td>".drawSingleCheckbox('intRankIDs[]', $ids[$i], $ranks[$i])."</td></tr>\n";
	}
	$strRet .= "<tr><td colspan=2>".drawSubmit('deleteRank', 'Remove Selected')."</td></tr>\n";
	$strRet .= "</table>\n";
	return $strRet;
}

function listAlignments($alignments, $ids)
{
	$strRet = "<table>\n";
	for($i=0;$i<count($alignments);$i++)
	{
//		$strRet .= "<tr><td>".drawSingleCheckbox('intAlignmentIDs[]', $alignments[$i], $ids[$i])."</td></tr>\n";
		$strRet .= "<tr><td>".drawSingleCheckbox('intAlignmentIDs[]', $ids[$i], $alignments[$i])."</td></tr>\n";
	}
	$strRet .= "<tr><td colspan=2>".drawSubmit('deleteAlignment', 'Remove Selected')."</td></tr>\n";
	$strRet .= "</table>\n";
	return $strRet;
}

function listSources($sources, $urls, $ids)
{
	$strRet = "<table>\n";
	for($i=0;$i<count($sources);$i++)
	{
//		$strRet .= "<tr><td>".drawSingleCheckbox('intSourceIDs[]', $sources[$i], $ids[$i])."</td></tr>\n";
		$strRet .= "<tr><td>".drawSingleCheckbox('intSourceIDs[]', $ids[$i], $sources[$i])."</td></tr>\n";
	}
	$strRet .= "<tr><td colspan=2>".drawSubmit('deleteSource', 'Remove Selected')."</td></tr>\n";
	$strRet .= "</table>\n";
	return $strRet;
}

function displayGLGod($g)
{
	$strRet = "";
	$strRet .= "<table>\n";
	$strRet .= "<tr><td colspan=2 valign=top><b>".$g[strName]."</b></td></tr>\n";				// Name
			
		$rString = "";
		$ranks = getGLGodsRanks($g[intGodID]);
		$first = 0;
		while($r = mysql_fetch_assoc($ranks))
		{	
			if($first == 0)
			{
				$first = 1;
				$rString .= $r[strRankName]."";		
			}
			else
				$rString .= ", ".$r[strRankName]."";		
		}
		$strRet .= "<tr><td colspan=2 valign=top>".$rString."</td></tr>\n";					// Rank 			
					
		$alString = "";
		$alignments = getGLGodsAlignments($g[intGodID]);
		$first = 0;
		while($al = mysql_fetch_assoc($alignments))
		{
			if($first == 0)
			{
				$first = 1;
				$alString .= "".$al[strAlignmentName]."";
			}
			else
				$alString .= ", ".$al[strAlignmentName]."";
		}
		$strRet .= "<tr><td valign=top>Alignment: </td><td>".$alString."</td></tr>\n";			// Alignment 			

		$assets = getGLGodsAssets($g[intGodID]);
		$first = 0;
		while($as = mysql_fetch_assoc($assets))
		{
			if($first == 0)
			{
				$first = 1;
				$asString .= "".$as[strAssetName]."";
			}
			else
				$asString .= ", ".$as[strAssetName]."";
		}
		$strRet .= "<tr><td valign=top>Portfolio: </td><td>".$asString."</td></tr>\n";			// Portfolio 

		$sString = "";
		$urlString = "";
		$sources = getGLGodsSources($g[intGodID]);
		$first = 0;
		while($s = mysql_fetch_assoc($sources))
		{
			if($first == 0)
			{
				$first = 1;
				if(strlen($s[strSourceURL])>0)
					$sString .= "<a href='".$s[strSourceURL]."'>".$s[strSourceName]."</a>";			
				else
					$sString .= "".$s[strSourceName]."";
			}
			else
			{
				if(strlen($s[strSourceURL])>0)
					$sString .= ", <a href='".$s[strSourceURL]."'>".$s[strSourceName]."</a>";			
				else
					$sString .= ", ".$s[strSourceName]."";
			}
		}
		$strRet .= "<tr><td valign=top>Sources: </td><td>".$sString."</td></tr>\n";				// Sources 			
		
	$strRet .="</table>\n";
	$strRet .="<hr>\n";
	return '<html><body style="background:#EEEEE7;">'.$strRet.'</body></html>';
}
// OUTPUT WEBPAGE	-----------------------------
include(cPathPrefix . '/layout_invis.php');
?>