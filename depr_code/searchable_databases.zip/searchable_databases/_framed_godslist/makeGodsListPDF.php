<?
// **************************************************
// Name: index.php
// Author: edobrzel 08/18/2003 (based on "index.php" written by bast)
// Purpose: Main/home content page.
// Notes:
//    (none)
// Copyright � 2003 Planewalker.com. All Rights Reserved
// **************************************************
// Change History:
// MM/DD/YYYY User     Comment 
// ---------- -------- -------
// 02/01/2004 edobrzel Hooked up to dynamic section text code.
// **************************************************
define('cPathPrefix', '..');
$blnHTMLArea = 1;
$extraFiles = array("/DB_GodsList.php");

function get_admin_menu(){
    $allowed_uids = array('1352', '1'); //1352 => alzrius, 1=>clueless
    $menu     = '';
    
    $uid     = $_COOKIE['db_drupal_uid'];
    $name     = $_COOKIE['db_drupal_name'];
    
    if(in_array($uid, $allowed_uids)){
        $menu = '<div>Welcome, '.$name.'! Use the menu below to update the Gods List.</div>';
        $menu .= '<div align="center"> '.
                    '<a href="index.php">View Gods</a> '.
                    '| <a href="editGods.php">Edit Gods</a> '.
                    '| <a href="editQualities.php">Edit Qualities</a> '.
                    '| <a href="makeGodsListPDF.php">Remake Gods List PDF</a> '.
                    '| <a href="upload.php">Upload File</a> '.
                    '| <a href="viewPDF.php" target="_blank">View PDF</a> '.
                    '</div><br><br>';        
    }
    return $menu;
}

function do_content()
{
    // **************************************************
    // * Name: do_content
    // * Purpose: Main content rederer.  Called by Layout.
    // * Output: [String] Returns content to be rendered.
    // **************************************************
    $cFunctionName = 'do_content';
    

    $allowed_uids = array('1352', '1'); //1352 => alzrius, 1=>clueless
    $uid     = $_COOKIE['db_drupal_uid'];
    $name     = $_COOKIE['db_drupal_name'];
    if(!in_array($uid, $allowed_uids)){
        header('Location:index.php');
        exit;
    }
    
    $submitMake = getRequest(submitMake);
    if(strlen($submitMake)>0)
    {
        $strData = getRequest(strData);
        if(strlen($strData)>0)
            editCoreMiscData('godListPrelude', $strData);

        $gods = getGLGods();
        
        define('FPDF_FONTPATH', cPathPrefix.'/include/fpdf/font/');
        require(cPathPrefix."/include/fpdf/bookmark.php");
    
        class PDF_Planewalker extends PDF_Bookmark
        {
            //Page header, appears under text
            function Header()
            {
                //Watermark Logo
                //$this->Image('http://www.planewalker.com/downloads/godslist/images/GL_logo.jpg',180,265,25,25);
            }

            //Page footer, appears over text
            function Footer()
            {
                //Position at 1.5 cm from bottom
                $this->SetY(-15);
                //Arial italic 8
                $this->SetFont('Arial','I',8);
                //Page number
                $this->Cell(0,10,'Planewalker.com, '.formatDate(time(),1).' : Page '.$this->PageNo() ,0,0,'C');
            }
        }

        $pdf=new PDF_Planewalker();
        $pdf->SetAuthor("Planewalker: Alzrius");
        $pdf->SetCreator("Planewalker PDF Generator");
        $pdf->SetSubject("God List");
        $pdf->SetTitle("God's List: ".formatDate(time(),1));
        $pdf->Open();

        //Page 1
        // If auto page breaking is enabled, the cell will auto break for the page.
        $pdf->AddPage();
        $pdf->SetFont('Arial','',12);
        $pdf->WriteHTML($strData,1);
        $pdf->MultiCell(0,6, "");                                // Spacer 
        $pdf->MultiCell(0,6, "");                                // Spacer         
//        $letter = "";
        while($g = mysql_fetch_assoc($gods))
        {
            if(strlen($g[strName])>0)
            {
                $first = substr(trim($g[strName]),0,1);
                if($first!=$letter)
                {
                    $letter = $first;
                    $pdf->Bookmark($first,0,-1);                    //Bookmark at a point. (-1 equals 
                    $pdf->Bookmark(trim($g[strName]),1,-1);                //Bookmark at a point. (-1 equals here)
                    $strRet .= "<div><b>Bookmarked Letter: $first</b></div>";
                    $strRet .= "<div>Bookmarked: $g[strName]</div>";
                }
                else
                {
                    $pdf->Bookmark(trim($g[strName]),1,-1);                //Bookmark at a point. (-1 equals here)        
                    $strRet .= "<div>Bookmarked: $g[strName]</div>";
    //                print_r($g);
    //                $strRet .= "<hr>";
                }

                $pdf->SetFont('Arial','',15);                        // Change to title font. *** INSERT HERE ***

                $pdf->MultiCell(0,6, $g[strName]);                    // Name. 

                $pdf->SetFont('Arial','',12);                        // Change to normal font. *** INSERT HERE ***
                                                                                    
                $rString = "";
                $ranks = getGLGodsRanks($g[intGodID]);
                $first = 0;
                while($r = mysql_fetch_assoc($ranks))
                {
                    if($first==0)
                    {
                        $first=1;
                        $rString .= "".$r[strRankName]."";        
                    }
                    else
                        $rString .= ", ".$r[strRankName]."";        
                }
                $pdf->MultiCell(0,6, "".$rString);                    // Rank             
                            
                $alString = "";
                $alignments = getGLGodsAlignments($g[intGodID]);
                $first = 0;
                while($al = mysql_fetch_assoc($alignments))
                {
                    if($first==0)
                    {
                        $first=1;
                        $alString .= $al[strAlignmentName]."";
                    }
                    else
                        $alString .= ", ".$al[strAlignmentName]."";
                }
                $pdf->MultiCell(0,6, "Alignment: ".$alString);        // Alignment             
                            
                $asString = "";
                $assets = getGLGodsAssets($g[intGodID]);
                $first = 0;
                while($as = mysql_fetch_assoc($assets))
                {
                    if($first==0)
                    {
                        $first=1;
                        $asString .= $as[strAssetName]."";
                    }
                    else
                        $asString .= ", ".$as[strAssetName]."";
                }
                $pdf->MultiCell(0,6, "Portfolio: ".$asString);        // Portfolio     
                
                $sString = "";
                $urlString = "";
                $sources = getGLGodsSources($g[intGodID]);
                $first = 0;
                while($s = mysql_fetch_assoc($sources))
                {
                    if($first==0)
                    {
                        $first=1;
                        if(strlen($s[strSourceURL])>0)
                            $sString .= $s[strSourceName]." (".$s[strSourceURL].")";
                        else
                            $sString .= $s[strSourceName]."";        
                    }
                    else
                    {
                        if(strlen($s[strSourceURL])>0)
                            $sString .= ", ".$s[strSourceName]." (".$s[strSourceURL].")";
                        else
                            $sString .= ", ".$s[strSourceName]."";                
                    }
                }
                $pdf->MultiCell(0,6, "Sources: ".$sString);            // Sources             
                
                $pdf->MultiCell(0,6, "");                            // Spacer         
            }
        }    
        
        $pdf->SetFont('Arial','',15);
        $pdf->MultiCell(0,6, "Sources");
        $sources = getGLSources();
        $pdf->SetFont('Arial','',12);
        while($s = mysql_fetch_assoc($sources))
        {
            $pdf->MultiCell(0,6, $s[strSourceName]."  ".$s[strSourceURL]);
        }

        $file = cPathPrefix.'/_framed_godslist/files/gods_list.pdf';
        //Save PDF to file
        $pdf->Output($file);

        $strRet .= "<div align=center><b>File saved to: <a href=http://www.planewalker.com/downloads/godslist/files/gods_list.pdf>http://www.planewalker.com/downloads/files/gods_list.pdf</a></b></div><br><br>";
    }

    $prelude = getCoreMiscData('godListPrelude');
    $prelude = mysql_fetch_assoc($prelude);

    $strRet .= "<form method=post action=''>\n";
    $strRet .= "<table>\n";
    $strRet .= "\t<tr>\n";
    $strRet .= "\t\t<td nowrap>Page Text:</td>\n";
    $strRet .= "\t\t<td>";
    $strRet .= "<div class='rtfTextArea' align=center>\n\n";
    $strRet .= drawTextbox('strData', $prelude[strData], 1, 1);
    $strRet .= "\n\n<br>This text form editor is compatible with IE 5.5 and up, and Mozilla 1.3 and up. If you are still seeing a plain text area form here,
    then it is suggested that you upgrade your browser. If this is not possible, please use html tags to format your entry so it
    can be read.\n\n";
    $strRet .= "\n\n</div>\n\n";
    $strRet .= "</td>\n";
    $strRet .= "\t</tr>\n";
    $strRet .= "<tr><td colspan=2>".drawSubmit('submitMake', 'Create New God List Download')."</td></tr>\n";
    $strRet .= "</table>\n";
    $strRet .= " <script type=\"text/javascript\" defer=\"1\"> \n
        var config = new HTMLArea.Config(); 
        // create a new configuration object 
        // having all the default values
        config.width = '550px';
        config.height = '300px';
        config.statusBar=false;
        config.sizeIncludesToolbar = false;
        HTMLArea.replace('strData', config); 
        </script>\n\n";
    $strRet .= "</form>\n";
    return '<html><body style="background:#EEEEE7;">'.get_admin_menu().$strRet.'</body></html>';
}

// OUTPUT WEBPAGE    -----------------------------
include(cPathPrefix . '/layout_invis.php');
?>