<?
// **************************************************
// Name: index.php
// Author: edobrzel 08/18/2003 (based on "index.php" written by bast)
// Purpose: Main/home content page.
// Notes:
//	(none)
// Copyright � 2003 Planewalker.com. All Rights Reserved
// **************************************************
// Change History:
// MM/DD/YYYY User     Comment 
// ---------- -------- -------
// 02/01/2004 edobrzel Hooked up to dynamic section text code.
// **************************************************
define('cPathPrefix', '..');
define('drupalRoot', '../..');

function get_admin_menu(){

	$allowed_uids = array('1352', '1'); //1352 => alzrius, 1=>clueless
	$uid 	= $_COOKIE['db_drupal_uid'];
	$name 	= $_COOKIE['db_drupal_name'];
	if(in_array($uid, $allowed_uids)){
		$menu = '<div>Welcome, '.$name.'! Use the menu below to update the Gods List.</div>';
		$menu .= '<div align="center"> '.
					'<a href="index.php">View Gods</a> '.
					'| <a href="editGods.php">Edit Gods</a> '.
					'| <a href="editQualities.php">Edit Qualities</a> '.
					'| <a href="makeGodsListPDF.php">Remake Gods List PDF</a> '.
					'| <a href="upload.php">Upload File</a> '.
					'| <a href="viewPDF.php" target="_blank">View PDF</a> '.
					'| <a href="viewCSV.php" target="_blank">View CSV</a> '.
					'</div><br><br>';		
	}
	return $menu;
}

function do_content()
{
	// **************************************************
	// * Name: do_content
	// * Purpose: Main content rederer.  Called by Layout.
	// * Output: [String] Returns content to be rendered.
	// **************************************************
	$cFunctionName = 'do_content';
	
	$submitSearch = getRequest('submitSearch');	
	$submitCreate = getRequest('submitCreate');
	
	if( strlen($submitSearch)>0 || strlen($submitCreate)>0 )
	{
		$strName = getRequest('strName');
		$intRankID = getRequest('intRankID');
		$strRankName = getRequest('strRankName');
		$intAlignmentID = getRequest('intAlignmentID');
		$strAlignmentName = getRequest('strAlignmentName');
		$intAssetID = getRequest('intAssetID');
		$strAssetName = getRequest('strAssetName');
		$strSourceName = getRequest('strSourceName');
		$keys = array();
		if(strlen($strName)>0)
			$keys[strName] =  '%'.$strName.'%';
		if(strlen($intRankID)>0 && $intRankID!=-1)
			$keys[intRankID] = $intRankID;		
		if(strlen($strRankName)>0)
			$keys[strRankName] = $strRankName;		
		if(strlen($intAlignmentID)>0 && $intAlignmentID!=-1)
			$keys[intAlignmentID] = $intAlignmentID;		
		if(strlen($strAlignmentName)>0)
			$keys[strAlignmentName] = $strAlignmentName;	
		if(strlen($intAssetID)>0 && $intAssetID!=-1)
			$keys[intAssetID] = $intAssetID;		
		if(strlen($strAssetName)>0)
			$keys[strAssetName] = $strAssetName;	
		if(strlen($strSourceName)>0)
			$keys[strSourceName] = '%'.$strSourceName.'%';
		$andor = "AND";
	}

	if(strlen($submitCreate)>0 && count($keys)>0)
	{
		// Create tmp PDF. Show there.
		$_SESSION[godListKeys] = $keys;	//Save to Session.
		header('Location:viewPDF.php');
	}
	else if(strlen($submitSearch)>0 && count($keys)>0)
	{
		$gods = searchGLGodsList($keys, $andor);
		// Show Here.
		$strRet .= "<div align=center><hr><b>Your search results:</b><hr></div>";
		while($g = mysql_fetch_assoc($gods))
		{
			$strRet .= displayGLGod($g);
			$allowed_uids = array('1352', '1'); //1352 => alzrius, 1=>clueless
			$uid 	= $_COOKIE['db_drupal_uid'];
			$name 	= $_COOKIE['db_drupal_name'];
			if(in_array($uid, $allowed_uids)){
				$strRet .= "<form action=editGods.php method=post>".drawHidden('intGodID', $g[intGodID]).drawSubmit('edit','Edit God')."</form>";
			}
		}
		$strRet .= "<br><br><hr>";
	}
	else if(count($keys)==0)
		$strRet .= "<div align=center><b>Please enter search terms, or consider <a href='files/gods_list.pdf' target='_blank'>downloading the full Gods List PDF</a>.</b></div>";
	
//	if(isAllowed('editGodsList'))
//	{
//		$strRet .= "<form action=editGods.php method=post>".drawHidden('intGodID', -1).drawSubmit('edit','Add A New God')."</form>";
//	}
	
	$strRet .= "
	<form action='' method='post'>
	<table>
	<tr>
		<td style='width:75px;'>Name: </td>
		<td>".drawText(strName,'',50)."</td>
	</tr>
	<tr>
		<td style='width:75px;'>Rank: </td>
		<td>".drawText(strRankName,'',50)."</td>
	</tr>
	<tr>
		<td style='width:75px;'>or select:</td>
		<td>&nbsp;&nbsp;&nbsp;".dropdownRanks()."</td>
	</tr>
	<tr>
		<td style='width:75px;'>Alignment: </td>
		<td>".drawText(strAlignmentName,'',50)."</td>		
	</tr>
	<tr>
		<td style='width:75px;'>or select:</td>
		<td>&nbsp;&nbsp;&nbsp;".dropdownAlignments()."</td>
	</tr>
	<tr>
		<td style='width:75px;'>Portfolio: </td>
		<td>".drawText(strAssetName,'',50)."</td>
	</tr>
	<tr>
		<td style='width:75px;'>or select:</td>
		<td>&nbsp;&nbsp;&nbsp;".dropdownAssets()."</td>
	</tr>
	<tr>
		<td style='width:75px;'>Source: </td>
		<td>".drawText(strSourceName,'',50)."</td>
	</tr>
	<tr>
		<td colspan=2>".drawSubmit(submitSearch, 'Search').drawSubmit(submitCreate, 'Search, Give it in PDF')."</td>
	</tr>
	</table>
	</form>";

    
	$allowed_uids = array('1352', '1'); //1352 => alzrius, 1=>clueless
	$uid 	= $_COOKIE['db_drupal_uid'];
	$name 	= $_COOKIE['db_drupal_name'];
    $blnOverride = 0;
	if(in_array($uid, $allowed_uids)){
        $blnOverride = 1;
    }
	$strRet .= drawSectionText('/downloads/godslist/godList.php', $blnOverride);
    
	return get_admin_menu().$strRet;

//	if(isAllowed('editGodsList'))
//	{
//		$strRet .= "<div align=center><a href=makeGodsListPDF.php>Create a New GodsList Download</a></div>";
//	}
}

function dropdownAssets()
{
	$Assets = getGLAssets();
	$strRet .= "<select name=intAssetID style='width:300px'>\n";
	$strRet .= "<option value=-1 SELECTED></option>";
	while($val = mysql_fetch_assoc($Assets))
	{
		$strRet .= "<option value=".$val[intAssetID].">".$val[strAssetName]."</option>\n";
	}
	$strRet .= "</select>\n";
	return $strRet;
}

function dropdownRanks()
{
	$Ranks = getGLRanks();
	$strRet .= "<select name=intRankID style='width:300px'>\n";
	$strRet .= "<option value=-1 SELECTED></option>";
	while($val = mysql_fetch_assoc($Ranks))
	{
		$strRet .= "<option value=".$val[intRankID].">".$val[strRankName]."</option>\n";
	}
	$strRet .= "</select>\n";
	return $strRet;
}

function dropdownAlignments()
{
	$Alignments = getGLAlignments();
	$strRet .= "<select name=intAlignmentID style='width:300px'>\n";
	$strRet .= "<option value=-1 SELECTED></option>";
	while($val = mysql_fetch_assoc($Alignments))
	{
		$strRet .= "<option value=".$val[intAlignmentID].">".$val[strAlignmentName]."</option>\n";
	}
	$strRet .= "</select>\n";
	return $strRet;
}

function dropdownSources()
{
	$Sources = getGLSources();
	$strRet .= "<select name=intSourceID style='width:300px'>\n";
	$strRet .= "<option value=-1 SELECTED></option>";
	while($val = mysql_fetch_assoc($Sources))
	{
		$strRet .= "<option value=".$val[intSourceID].">".$val[strSourceName]."</option>\n";
	}
	$strRet .= "</select>\n";
	return $strRet;
}

function displayGLGod($g)
{
	$strRet = "";
	$strRet .= "<table>\n";
	$strRet .= "<tr><td colspan=2 valign=top><b>".$g[strName]."</b></td></tr>\n";				// Name
			
		$rString = "";
		$ranks = getGLGodsRanks($g[intGodID]);
		$first = 0;
		while($r = mysql_fetch_assoc($ranks))
		{	
			if($first == 0)
			{
				$first = 1;
				$rString .= $r[strRankName]."";		
			}
			else
				$rString .= ", ".$r[strRankName]."";		
		}
		$strRet .= "<tr><td colspan=2 valign=top>".$rString."</td></tr>\n";					// Rank 			
					
		$alString = "";
		$alignments = getGLGodsAlignments($g[intGodID]);
		$first = 0;
		while($al = mysql_fetch_assoc($alignments))
		{
			if($first == 0)
			{
				$first = 1;
				$alString .= "".$al[strAlignmentName]."";
			}
			else
				$alString .= ", ".$al[strAlignmentName]."";
		}
		$strRet .= "<tr><td valign=top>Alignment: </td><td>".$alString."</td></tr>\n";			// Alignment 			

		$assets = getGLGodsAssets($g[intGodID]);
		$first = 0;
		while($as = mysql_fetch_assoc($assets))
		{
			if($first == 0)
			{
				$first = 1;
				$asString .= "".$as[strAssetName]."";
			}
			else
				$asString .= ", ".$as[strAssetName]."";
		}
		$strRet .= "<tr><td valign=top>Portfolio: </td><td>".$asString."</td></tr>\n";			// Portfolio 

		$sString = "";
		$urlString = "";
		$sources = getGLGodsSources($g[intGodID]);
		$first = 0;
		while($s = mysql_fetch_assoc($sources))
		{
			if($first == 0)
			{
				$first = 1;
				if(strlen($s[strSourceURL])>0)
					$sString .= "<a href='".$s[strSourceURL]."'>".$s[strSourceName]."</a>";			
				else
					$sString .= "".$s[strSourceName]."";
			}
			else
			{
				if(strlen($s[strSourceURL])>0)
					$sString .= ", <a href='".$s[strSourceURL]."'>".$s[strSourceName]."</a>";			
				else
					$sString .= ", ".$s[strSourceName]."";
			}
		}
		$strRet .= "<tr><td valign=top>Sources: </td><td>".$sString."</td></tr>\n";				// Sources 			
		
	$strRet .="</table>\n";
	$strRet .="<hr>\n";
	return '<html><body style="background:#EEEEE7;">'.$strRet.'</body></html>';
}
// OUTPUT WEBPAGE	-----------------------------
include(cPathPrefix . '/layout_invis.php');
?>