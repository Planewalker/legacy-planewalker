<?
// **************************************************
// Name: index.php
// Author: edobrzel 08/18/2003 (based on "index.php" written by bast)
// Purpose: Main/home content page.
// Notes:
//	(none)
// Copyright � 2003 Planewalker.com. All Rights Reserved
// **************************************************
// Change History:
// MM/DD/YYYY User     Comment 
// ---------- -------- -------
// 02/01/2004 edobrzel Hooked up to dynamic section text code.
// **************************************************

define('cPathPrefix', '..');




function do_content()
{
	// **************************************************
	// * Name: do_content
	// * Purpose: Main content rederer.  Called by Layout.
	// * Output: [String] Returns content to be rendered.
	// **************************************************
	$cFunctionName = 'do_content';
	
	// draw out the section text

	$strRet .= drawSectionText($_SESSION['strSectionID']);
	return '<html><body style="background:#EEEEE7;">'.$strRet.'</body></html>';

}

// OUTPUT WEBPAGE	-----------------------------
include(cPathPrefix . '/layout_invis.php');
?>