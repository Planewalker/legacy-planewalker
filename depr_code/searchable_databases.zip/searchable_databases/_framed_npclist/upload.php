<?
// **************************************************
// Name: */upload.php
// Author: clueless --/--/----
// Purpose: Standalone file upload and process system for seciton managers.
// Notes: Creates folders /files /images if neither exist in folder with it.
// Copyright � 2003, 2004 Planewalker.com. All Rights Reserved
// **************************************************
// Change History:
// MM/DD/YYYY User     Comment 
// ---------- -------- -------
// **************************************************
define('cPathPrefix', '..');

function get_admin_menu(){

    $allowed_uids = array('1352', '1'); //1352 => alzrius, 1=>clueless
    $uid     = $_COOKIE['db_drupal_uid'];
    $name     = $_COOKIE['db_drupal_name'];
    if(in_array($uid, $allowed_uids)){
        $menu = '<div>Welcome, '.$name.'! Use the menu below to update the NPCs DB.</div>';
        $menu .= '<div align="center"> '.
                    '<a href="uploadNPC.php">Upload NPCs</a> '.
                    '| <a href="upload.php">Upload File</a> '.
                    '</div><br><br>';        
    }
    return $menu;
}

function do_content()
{
	// **************************************************
	// * Name: do_content
	// * Purpose: Main content renderer.  Called by Layout.
	// * Return: (none)
	// * Output: [String] Prints content to be rendered.
	// **************************************************

	$cFunctionName = 'do_content';
	

	$submitUpload = getValue('submitUpload', 0);
	$submitDelete = getValue('submitDelete', 0);

	if(strlen($submitUpload)>0)
	{
		$dir = getValue('dir', 0);
		if($dir=='images'||$dir=='files')
		{
			$dir = $dir."/";
			// Check directory location (vs. hacks)
			if(!is_dir($dir))
			{
				// Does the directory exist? If no. Make one.
				$strRet .= "<div align=center>Making directory.</div>";
				mkdir("$dir", 0777);
			}

			$file = $dir.basename($_FILES[newFile][name]);
			if (move_uploaded_file($_FILES[newFile][tmp_name], $file)) 
			{
				$strRet .=  "<div align=center>File is valid, and was successfully uploaded.</div>";
			}
			else
			{
				$strRet .= "<div align=center>Upload failed. Possible file upload attack!</div>";
			}
		}
		else
			$strRet .= "<div align=center>Not a directory.</div>";
	}

	if(strlen($submitDelete)>0)
	{
		$dir = getValue('filePath', 0);
		$name = getValue('fileName', 0);
		unlink($dir."/".$name);
	}

	// draw out the section text
	$strRet .= print_uploadForm();
	$strRet .= "<hr>";
	$strRet .= print_viewFiles();
	return $strRet;
}

function print_uploadForm()
{
	$arrValues = array("images", "files");
	$arrTags   = array("Images", "Files");
	$strRet .= "
		<form method=post action=upload.php enctype=multipart/form-data>
		<table align=center>
		<tr>
			<td>Locate File:</td>
			<td>".drawFile("newFile")."</td>
		</tr>
		<tr>
			<td>Directory:</td>
			<td>
				".drawSelectOptions("dir", $arrValues, $arrTags, "")."
			</td>
		</tr>
		<tr>
			<td colspan=2>".drawSubmit("submitUpload", "Upload File")."</td>
		</tr>
		</table>
		</form>
		";
	return $strRet;
}

function print_viewFiles()
{
	$strRet .= "<div align=center><b>Files</b></div>\n";
	$strRet .= display_Files("files");
	$strRet .= "<br><br><div align=center><b>Images</b></div>\n";
	$strRet .= display_Files("images");
	return $strRet;
}

function display_Files($path)
{
	$overlook = array(".", "..", "index.php");
	if(!is_dir($path))
	{
		// Does the directory exist? If no. Make one.
		$strRet .= "<div align=center>Making directory.</div>";
		mkdir($path."/", 0777);
	}

	if($dir = opendir($path)) 
	{ 
		while (false !== ($file = readdir($dir))) 
		{ 
			if( !(in_array($file, $overlook)) ) 
			{
				if (!is_dir($path."/".$file)) 
				{
					$strRet .= "
						<form action=upload.php method=post>
						<table><tr>
							<td><a href='".$path."/".$file."' target=_blank>".$file."</a><br></td>\n
							<td>".drawHidden("filePath", $path).drawHidden("fileName", $file).
							drawSubmit("submitDelete", "Delete")."</td>\n
						</tr></table>
						</form>
						";
				} 
			} 
		} 
		closedir($dir); 
	}
	return '<html><body style="background:#EEEEE7;">'.get_admin_menu().$strRet.'</body></html>';
}

// OUTPUT WEBPAGE	-----------------------------

include(cPathPrefix . '/layout_invis.php');

?>