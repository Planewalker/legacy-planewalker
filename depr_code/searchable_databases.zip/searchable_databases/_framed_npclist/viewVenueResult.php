<?
// **************************************************
// Name: index.php
// Author: edobrzel 08/18/2003 (based on "index.php" written by bast)
// Purpose: Main/home content page.
// Notes:
//	(none)
// Copyright � 2003 Planewalker.com. All Rights Reserved
// **************************************************
// Change History:
// MM/DD/YYYY User     Comment 
// ---------- -------- -------
// 02/01/2004 edobrzel Hooked up to dynamic section text code.
// **************************************************

define('cPathPrefix', '..');

function do_content()
{
	// **************************************************
	// * Name: do_content
	// * Purpose: Main content rederer.  Called by Layout.
	// * Output: [String] Returns content to be rendered.
	// **************************************************
	$cFunctionName = 'do_content';
	


	$keys		= getRequest('strKeywords');
	$blnResult	= getRequest('blnResult');

	if($blnResult==2)
	{
		// As Excel
		header("Content-Type: application/vnd.ms-excel");
		header("Expires: 0");
		header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
		header("Content-Disposition: attachment;filename=VenuesearchResults.xls");

		$keys		= explode(' ', $keys);
		$search		= searchVenues($keys);
		$fields		= getVenueTableFields();

		$retStr .= "<table border=1><tr>";
		for($i=1;$i<count($fields);$i++)
		{
			$retStr .= "<td valign=top nowrap><b>".str_replace('_', ' ', $fields[$i])."</b></td>";
		}
		$retStr .= "</tr><tr>";
		while($aS = mysql_fetch_assoc($search))
		{
			for($i=1;$i<count($fields);$i++)
			{
				$retStr .= "<td valign=top>".$aS[$fields[$i]]."</td>";
			}
			$retStr .= "</tr><tr>";
		}
		$retStr .= "</table>";
	}

	if($blnResult==3)
	{
		// As PDF
		header("Content-Type: application/pdf");
		header("Expires: 0");
		header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
		header("Content-Disposition: attachment;filename=VenuesearchResults.pdf");
		$keys		= explode(' ', $keys);
		$search		= searchVenues($keys);
		$fields		= getVenueTableFields();

		define('FPDF_FONTPATH', cPathPrefix.'/include/fpdf/font/');
		require(cPathPrefix."/include/fpdf/bookmark.php");
	
		class PDF_Planewalker extends PDF_Bookmark
		{
			//Page header, appears under text
			function Header()
			{
				//Watermark Logo
				$this->Image('http://www.planewalker.com/downloads/godslist/images/GL_logo.jpg',180,265,25,25);
			}

			//Page footer, appears over text
			function Footer()
			{
				//Position at 1.5 cm from bottom
				$this->SetY(-15);
				//Arial italic 8
				$this->SetFont('Arial','I',8);
				//Page number
				$this->Cell(0,10,'Planewalker.com, '.formatDate(time(),1).' : Page '.$this->PageNo() ,0,0,'C');
			}
		}
		
		$pdf=new PDF_Planewalker();
		$pdf->SetAuthor("Planewalker: Ambrus");
		$pdf->SetCreator("Planewalker PDF Generator");
		$pdf->SetSubject("Venue List");
		$pdf->SetTitle("Venue List: ".formatDate(time(),1));
		$pdf->Open();
		$pdf->SetFont('Arial','',15);
		$pdf->AddPage();
		$pdf->SetFont('Arial','',15);
		$pdf->MultiCell(0,6, "Search Results:");
		$pdf->MultiCell(0,6, "");

		$pdf->SetFont('Arial','',12);						// Change to normal font. *** INSERT HERE ***				
		while($aS = mysql_fetch_assoc($search))
		{
			for($i=1;$i<count($fields);$i++)
			{
				$pdf->MultiCell(0,6, "".$fields[$i].": ".$aS[$fields[$i]]);
			}
		}
		$pdf->MultiCell(0,6, "");								
		$pdf->Output();
	}

	if($blnResult==4)
	{
		// As CSV Text file
		header("Content-Type: application/text");
		header("Expires: 0");
		header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
		header("Content-Disposition: attachment;filename=VenuesearchResults.txt");
		print_r($keys);
		$keys		= explode(' ', $keys);
		$search		= searchVenues($keys);
		$fields		= getVenueTableFields();

		$retStr .= "";
		for($i=1;$i<count($fields);$i++)
		{
			$retStr .= " ".str_replace('_', ' ', $fields[$i]).",";
		}
		$retStr .= "\n";
		while($aS = mysql_fetch_assoc($search))
		{
			for($i=1;$i<count($fields);$i++)
			{
				$retStr .= " ".$aS[$fields[$i]].",";
			}
			$retStr .= "\n";
		}
		$retStr .= "";
	}

	return $retStr;
}

// OUTPUT WEBPAGE	-----------------------------
include(cPathPrefix . '/layout_invis.php');
?>