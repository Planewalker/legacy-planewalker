<?
// **************************************************
// Name: index.php
// Author: edobrzel 08/18/2003 (based on "index.php" written by bast)
// Purpose: Main/home content page.
// Notes:
//    (none)
// Copyright � 2003 Planewalker.com. All Rights Reserved
// **************************************************
// Change History:
// MM/DD/YYYY User     Comment 
// ---------- -------- -------
// 02/01/2004 edobrzel Hooked up to dynamic section text code.
// **************************************************

define('cPathPrefix', '..');
define('drupalRoot', '../..');

function get_admin_menu($mode){
    if($mode=='venues'){
        $allowed_uids = array('2109', '1'); //1352 => ambrus, 1=>clueless
        $uid     = $_COOKIE['db_drupal_uid'];
        $name     = $_COOKIE['db_drupal_name'];
        if(in_array($uid, $allowed_uids)){
            $menu = '<div>Welcome, '.$name.'! Use the menu below to update the Venues DB.</div>';
            $menu .= '<div align="center"> '.
                        '<a href="uploadVenue.php">Upload Venues</a> '.
                        '| <a href="upload.php">Upload File</a> '.
                        '</div><br><br>';        
        }
        return $menu;
    } else if ($mode=='npcs'){
        $allowed_uids = array('1352', '1'); //1352 => alzrius, 1=>clueless
        $uid     = $_COOKIE['db_drupal_uid'];
        $name     = $_COOKIE['db_drupal_name'];
        if(in_array($uid, $allowed_uids)){
            $menu = '<div>Welcome, '.$name.'! Use the menu below to update the NPCs DB.</div>';
            $menu .= '<div align="center"> '.
                        '<a href="uploadNPC.php">Upload NPCs</a> '.
                        '| <a href="upload.php">Upload File</a> '.
                        '</div><br><br>';        
        }
        return $menu;
    }
    return '';
}

function do_content()
{

$_SESSION['strViewPermission'] = 'guestView';

    // **************************************************
    // * Name: do_content
    // * Purpose: Main content rederer.  Called by Layout.
    // * Output: [String] Returns content to be rendered.
    // **************************************************
    $cFunctionName = 'do_content';
    
    // draw out the section text
    $mode = getRequest('mode');

    if($mode == 'npcs' ){
        
        $submitSearch = getRequest('submitSearch');
        if(strlen($submitSearch)>0)
        {
            $strKeywords    = getRequest('strKeywords');
            $blnResult        = getRequest('blnResult');
            
            if($blnResult==1)
            {
                $keys = explode(' ', $strKeywords);
                $search = searchNPCs($keys);
                $fields = getNPCTableFields();

                $popretStr .= "<table cellspacing=0 class='NPCList'><tr>";
                for($i=1;$i<count($fields);$i++)
                {
                    $popretStr .= "<td valign=top nowrap>".str_replace('_', ' ', $fields[$i])."</td>";
                }
                $popretStr .= "</tr><tr>";
                while($aS = mysql_fetch_assoc($search))
                {
                    for($i=1;$i<count($fields);$i++)
                    {
                        $style = '';
                        if($i%2==0)
                            $style = ' style="background:#ececec;" ';
                        $popretStr .= "<td valign=top".$style.">".$aS[$fields[$i]]."</td>";
                    }
                    $popretStr .= "</tr><tr>";
                }
                $popretStr .= "</table><hr><a href='javascript:self.close();'>close window</a>";

                // open the window
                $popupString .= "<script language='javascript' type='text/javascript'> ".
                    "function open_result_popup(){ ".
                    " new_win = window.open('popup.html', 'SearchResults', 'width=750,height=550,scrollbars=yes,resizable=yes'); ".
                    " if(new_win!=null){ ".                    
                    " new_win.document.write('<html><body>".str_replace("\n", " ",str_replace("'", "\'", $popretStr))."</body></html>'); ".
                    " new_win.focus(); ".
                    "} else { ".
                    " alert('You need to turn your popup blocker off for us to show you a popup of results.'); ".
                    "} ".
                    "} ".
                    "open_result_popup(); ".
                    "</script>";                
            }
            else {
            
                if($blnResult==2)
                {
                    // As Excel
                    header("Content-Type: application/vnd.ms-excel");
                    header("Expires: 0");
                    header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
                    header("Content-Disposition: attachment;filename=NPCsearchResults.xls");

                    $keys        = explode(' ', $keys);
                    $search        = searchNPCs($keys);
                    $fields        = getNPCTableFields();

                    $retStr .= "<table border=1><tr>";
                    for($i=1;$i<count($fields);$i++)
                    {
                        $retStr .= "<td valign=top nowrap><b>".str_replace('_', ' ', $fields[$i])."</b></td>";
                    }
                    $retStr .= "</tr><tr>";
                    $j=0;
                    while($aS = mysql_fetch_assoc($search))
                    {
                        for($i=1;$j<count($fields);$i++)
                        {
                            $retStr .= "<td valign=top>".$aS[$fields[$i]]."</td>";
                        }
                        $retStr .= "</tr><tr>";
                        $j++;
                    }
                    $retStr .= "</table>";
                }

                if($blnResult==3)
                {
                    // As PDF
                    header("Content-Type: application/pdf");
                    header("Expires: 0");
                    header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
                    header("Content-Disposition: attachment;filename=NPCsearchResults.pdf");
                    $keys        = explode(' ', $keys);
                    $search        = searchNPCs($keys);
                    $fields        = getNPCTableFields();

                    define('FPDF_FONTPATH', cPathPrefix.'/include/fpdf/font/');
                    require(cPathPrefix."/include/fpdf/bookmark.php");
                
                    class PDF_Planewalker extends PDF_Bookmark
                    {
                        //Page header, appears under text
                        function Header()
                        {
                            //Watermark Logo
                            //$this->Image('http://www.planewalker.com/downloads/godslist/images/GL_logo.jpg',180,265,25,25);
                        }

                        //Page footer, appears over text
                        function Footer()
                        {
                            //Position at 1.5 cm from bottom
                            $this->SetY(-15);
                            //Arial italic 8
                            $this->SetFont('Arial','I',8);
                            //Page number
                            $this->Cell(0,10,'Planewalker.com, '.formatDate(time(),1).' : Page '.$this->PageNo() ,0,0,'C');
                        }
                    }
                    
                    $pdf=new PDF_Planewalker();
                    $pdf->SetAuthor("Planewalker: Ambrus");
                    $pdf->SetCreator("Planewalker PDF Generator");
                    $pdf->SetSubject("NPC List");
                    $pdf->SetTitle("NPC List: ".formatDate(time(),1));
                    $pdf->Open();
                    $pdf->SetFont('Arial','',15);
                    $pdf->AddPage();
                    $pdf->SetFont('Arial','',15);
                    $pdf->MultiCell(0,6, "Search Results:");
                    $pdf->MultiCell(0,6, "");

                    $pdf->SetFont('Arial','',12);                        // Change to normal font. *** INSERT HERE ***                
                    while($aS = mysql_fetch_assoc($search))
                    {
                        for($i=1;$i<count($fields);$i++)
                        {
                            $pdf->MultiCell(0,6, "".$fields[$i].": ".$aS[$fields[$i]]);
                        }
                    }
                    $pdf->MultiCell(0,6, "");                                
                    $retStr = $pdf->Output("NPCList.pdf", "S");
                    //exit;
                }

                if($blnResult==4)
                {
                    // As CSV Text file
                    header("Content-Type: application/text");
                    header("Expires: 0");
                    header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
                    header("Content-Disposition: attachment;filename=NPCsearchResults.txt");
                    print_r($keys);
                    $keys        = explode(' ', $keys);
                    $search        = searchNPCs($keys);
                    $fields        = getNPCTableFields();

                    $retStr .= "";
                    for($i=1;$i<count($fields);$i++)
                    {
                        $retStr .= " ".str_replace('_', ' ', $fields[$i]).",";
                    }
                    $retStr .= "\n";
                    while($aS = mysql_fetch_assoc($search))
                    {
                        for($i=1;$i<count($fields);$i++)
                        {
                            $retStr .= " ".$aS[$fields[$i]].",";
                        }
                        $retStr .= "\n";
                    }
                    $retStr .= "";
                }
            }
            $DATA_RETURN = $retStr;
            $retStr = '';
        }
        
        $retStr .= "<form method=post action=''>";
        $retStr .=    "<table align=center>".
                        "<tr><td align=center>".
                            drawText('strKeywords', '').
                            drawSubmit('submitSearch', 'Search').
                        "</td></tr>".
                        "<tr><td align=center>Show: ".
                            "In popup <input type=radio name=blnResult value='1' CHECKED SELECTED style='border-width:0px;'> ".
                            "As Excel <input type=radio name=blnResult value='2' style='border-width:0px;'> ".
                            "As PDF <input type=radio name=blnResult value='3' style='border-width:0px;'> ".
                            "As Text File (comma delineated) <input type=radio name=blnResult value='4' style='border-width:0px;'> ".
                        "</td></tr>".
                        "<tr><td align=center><i>When selecting the popup display:<br>Make sure you are not blocking popups for this site.</i></td></tr>".
                    "</table>";
        $retStr .= "</form>";
        $retStr .= drawSectionText('/downloads/npclist/NPCList.php');    
        
    } else if($mode == 'venues'){

        $submitSearch = getRequest('submitSearch');
        if(strlen($submitSearch)>0)
        {
            $strKeywords    = getRequest('strKeywords');
            $blnResult        = getRequest('blnResult');
            if($blnResult==1)
            {
                $keys = explode(' ', $strKeywords);
                $search = searchVenues($keys);
                $fields = getVenueTableFields();

                $popretStr .= "<table cellspacing=0 class='VenueList'><tr>";
                for($i=1;$i<count($fields);$i++)
                {
                    $popretStr .= "<td valign=top nowrap>".str_replace('_', ' ', $fields[$i])."</td>";
                }
                $popretStr .= "</tr><tr>";
                $j = 0;
                while($aS = mysql_fetch_assoc($search))
                {
                    for($i=1;$i<count($fields);$i++)
                    {
                        $style = '';
                        if($j%2==0)
                            $style = ' style="background:#ececec;" ';
                        $popretStr .= "<td valign=top".$style.">".$aS[$fields[$i]]."</td>";   
                    }
                    $popretStr .= "</tr><tr>";
                    $j++;
                }
                $popretStr .= "</table><hr><a href='javascript:self.close();'>close window</a>";
                
                $retStr = '';
                // open the window
                $popupString .= "<script language='javascript' type='text/javascript'> ".
                    "function open_result_popup(){ ".
                    " new_win = window.open('popup.html', '_blank', 'width=750,height=550,scrollbars=yes,resizable=yes'); ".
                    " if(new_win!=null){ ".
                    " new_win.document.write('<html><body>".str_replace("\n", " ",str_replace("'", "\'", $popretStr))."</body></html>'); ".
                    " new_win.focus(); ".
                    "} else { ".
                    " alert('You need to turn your popup blocker off for us to show you a popup of results.'); ".
                    "} ".
                    "} ".
                    "open_result_popup(); ".
                    "</script>";

            }
            else {
                        
                $keys        = getRequest('strKeywords');
                $blnResult    = getRequest('blnResult');

                if($blnResult==2)
                {
                    // As Excel
                    header("Content-Type: application/vnd.ms-excel");
                    header("Expires: 0");
                    header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
                    header("Content-Disposition: attachment;filename=VenuesearchResults.xls");

                    $keys        = explode(' ', $keys);
                    $search        = searchVenues($keys);
                    $fields        = getVenueTableFields();

                    $retStr .= "<table border=1><tr>";
                    for($i=1;$i<count($fields);$i++)
                    {
                        $retStr .= "<td valign=top nowrap><b>".str_replace('_', ' ', $fields[$i])."</b></td>";
                    }
                    $retStr .= "</tr><tr>";
                    while($aS = mysql_fetch_assoc($search))
                    {
                        for($i=1;$i<count($fields);$i++)
                        {
                            $retStr .= "<td valign=top>".$aS[$fields[$i]]."</td>";
                        }
                        $retStr .= "</tr><tr>";
                    }
                    $retStr .= "</table>";
                }

                if($blnResult==3)
                {
                    // As PDF
                    header("Content-Type: application/pdf");
                    header("Expires: 0");
                    header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
                    header("Content-Disposition: attachment;filename=VenuesearchResults.pdf");
                    $keys        = explode(' ', $keys);
                    $search        = searchVenues($keys);
                    $fields        = getVenueTableFields();

                    define('FPDF_FONTPATH', cPathPrefix.'/include/fpdf/font/');
                    require(cPathPrefix."/include/fpdf/bookmark.php");
                
                    class PDF_Planewalker extends PDF_Bookmark
                    {
                        //Page header, appears under text
                        function Header()
                        {
                            //Watermark Logo
                            //$this->Image('http://www.planewalker.com/downloads/godslist/images/GL_logo.jpg',180,265,25,25);
                        }

                        //Page footer, appears over text
                        function Footer()
                        {
                            //Position at 1.5 cm from bottom
                            $this->SetY(-15);
                            //Arial italic 8
                            $this->SetFont('Arial','I',8);
                            //Page number
                            $this->Cell(0,10,'Planewalker.com, '.formatDate(time(),1).' : Page '.$this->PageNo() ,0,0,'C');
                        }
                    }
                    
                    $pdf=new PDF_Planewalker();
                    $pdf->SetAuthor("Planewalker: Ambrus");
                    $pdf->SetCreator("Planewalker PDF Generator");
                    $pdf->SetSubject("Venue List");
                    $pdf->SetTitle("Venue List: ".formatDate(time(),1));
                    $pdf->Open();
                    $pdf->SetFont('Arial','',15);
                    $pdf->AddPage();
                    $pdf->SetFont('Arial','',15);
                    $pdf->MultiCell(0,6, "Search Results:");
                    $pdf->MultiCell(0,6, "");

                    $pdf->SetFont('Arial','',12);                        // Change to normal font. *** INSERT HERE ***                
                    while($aS = mysql_fetch_assoc($search))
                    {
                        for($i=1;$i<count($fields);$i++)
                        {
                            $pdf->MultiCell(0,6, "".$fields[$i].": ".$aS[$fields[$i]]);
                        }
                    }
                    $pdf->MultiCell(0,6, "");                                
                    $retStr = $pdf->Output("VenuesList.pdf", "S");
                    //exit;
                }

                if($blnResult==4)
                {
                    // As CSV Text file
                    header("Content-Type: application/text");
                    header("Expires: 0");
                    header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
                    header("Content-Disposition: attachment;filename=VenuesearchResults.txt");
                    print_r($keys);
                    $keys        = explode(' ', $keys);
                    $search        = searchVenues($keys);
                    $fields        = getVenueTableFields();

                    $retStr .= "";
                    for($i=1;$i<count($fields);$i++)
                    {
                        $retStr .= " ".str_replace('_', ' ', $fields[$i]).",";
                    }
                    $retStr .= "\n";
                    while($aS = mysql_fetch_assoc($search))
                    {
                        for($i=1;$i<count($fields);$i++)
                        {
                            $retStr .= " ".$aS[$fields[$i]].",";
                        }
                        $retStr .= "\n";
                    }
                    $retStr .= "";
                }
                
            }
            
            $DATA_RETURN = $retStr;
            $retStr = '';
        }
            
        $retStr .= "<form method=post action=''>";
        $retStr .=    "<table align=center>".
                        "<tr><td align=center>".
                            drawText('strKeywords', '').
                            drawSubmit('submitSearch', 'Search').
                        "</td></tr>".
                        "<tr><td align=center>Show: ".
                            "In popup <input type=radio name=blnResult value='1' CHECKED SELECTED style='border-width:0px;'> ".
                            "As Excel <input type=radio name=blnResult value='2' style='border-width:0px;'> ".
                            "As PDF <input type=radio name=blnResult value='3' style='border-width:0px;'> ".
                            "As Text File (comma delineated) <input type=radio name=blnResult value='4' style='border-width:0px;'> ".
                        "</td></tr>".
                        "<tr><td align=center><i>When selecting the popup display:<br>Make sure you are not blocking popups for this site.</i></td></tr>".
                    "</table>";
        $retStr .= "</form>";
        
        $retStr .= drawSectionText('/downloads/npclist/venues.php');    
    } else if ($mode=='maps') {
        $retStr .= drawSectionText('/downloads/npclist/map.php');    

    } else {
        return '';
    }

    $retStr = get_admin_menu($mode).$popupString.$retStr;
    
    if(strlen($DATA_RETURN)>0)
        return $DATA_RETURN;
    else 
        return '<html><body style="background:#EEEEE7;">'.$retStr.'</body></html>';

}

// OUTPUT WEBPAGE    -----------------------------
include(cPathPrefix . '/layout_invis.php');
?>