<?
// **************************************************
// Name: index.php
// Author: edobrzel 08/18/2003 (based on "index.php" written by bast)
// Purpose: Main/home content page.
// Notes:
//	(none)
// Copyright � 2003 Planewalker.com. All Rights Reserved
// **************************************************
// Change History:
// MM/DD/YYYY User     Comment 
// ---------- -------- -------
// 02/01/2004 edobrzel Hooked up to dynamic section text code.
// **************************************************

define('cPathPrefix', '..');

function do_content()
{
	// **************************************************
	// * Name: do_content
	// * Purpose: Main content rederer.  Called by Layout.
	// * Output: [String] Returns content to be rendered.
	// **************************************************
	$cFunctionName = 'do_content';

	$submitSearch = getRequest('submitSearch');
	if(strlen($submitSearch)>0)
	{
		$strKeywords	= getRequest('strKeywords');
		$blnResult		= getRequest('blnResult');
		if($blnResult==1)
		{
			$keys = explode(' ', $strKeywords);
			$search = searchVenues($keys);
			$fields = getVenueTableFields();

			$retStr .= "<table cellspacing=0 class='VenueList'><tr>";
			for($i=1;$i<count($fields);$i++)
			{
				$retStr .= "<td valign=top nowrap>".str_replace('_', ' ', $fields[$i])."</td>";
			}
			$retStr .= "</tr><tr>";
			while($aS = mysql_fetch_assoc($search))
			{
				for($i=1;$i<count($fields);$i++)
				{
					$retStr .= "<td valign=top>".$aS[$fields[$i]]."</td>";
				}
				$retStr .= "</tr><tr>";
			}
			$retStr .= "</table><hr>";
		}
		else
			header("Location:viewVenueResult.php?strKeywords=".$strKeywords."&blnResult=".$blnResult);
	}
	
	$retStr .= drawSectionText($_SESSION['strSectionID']);

	$retStr .= "<form method=post action=''>";
	$retStr .=	"<table align=center>".
					"<tr><td align=center>".
						drawText('strKeywords', '').
						drawSubmit('submitSearch', 'Search').
					"</td></tr>".
					"<tr><td align=center>Show: ".
						"In page <input type=radio name=blnResult value='1' CHECKED SELECTED style='border-width:0px;'> ".
						"As Excel <input type=radio name=blnResult value='2' style='border-width:0px;'> ".
						"As PDF <input type=radio name=blnResult value='3' style='border-width:0px;'> ".
						"As Text File (comma delineated) <input type=radio name=blnResult value='4' style='border-width:0px;'> ".
					"</td></tr>".
					"<tr><td align=center></td></tr>".
				"</table>";
	$retStr .= "</form>";
	return '<html><body style="background:#EEEEE7;">'.$retStr.'</body></html>';
}

// OUTPUT WEBPAGE	-----------------------------
include(cPathPrefix . '/layout_invis.php');
?>