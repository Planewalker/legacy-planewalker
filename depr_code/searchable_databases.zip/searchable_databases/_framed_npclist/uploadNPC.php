<?
// **************************************************
// Name: index.php
// Author: edobrzel 08/18/2003 (based on "index.php" written by bast)
// Purpose: Main/home content page.
// Notes:
//	(none)
// Copyright � 2003 Planewalker.com. All Rights Reserved
// **************************************************
// Change History:
// MM/DD/YYYY User     Comment 
// ---------- -------- -------
// 02/01/2004 edobrzel Hooked up to dynamic section text code.
// **************************************************

define('cPathPrefix', '..');

function get_admin_menu(){

    $allowed_uids = array('1352', '1'); //1352 => alzrius, 1=>clueless
    $uid     = $_COOKIE['db_drupal_uid'];
    $name     = $_COOKIE['db_drupal_name'];
    if(in_array($uid, $allowed_uids)){
        $menu = '<div>Welcome, '.$name.'! Use the menu below to update the NPCs DB.</div>';
        $menu .= '<div align="center"> '.
                    '<a href="uploadNPC.php">Upload NPCs</a> '.
                    '| <a href="upload.php">Upload File</a> '.
                    '</div><br><br>';        
    }
    return $menu;

}



function do_content()
{
	// **************************************************
	// * Name: do_content
	// * Purpose: Main content rederer.  Called by Layout.
	// * Output: [String] Returns content to be rendered.
	// **************************************************
	$cFunctionName = 'do_content';
	include(cPathPrefix.'/include/excel/reader.php');

	$submitFile = getRequest('submitFile');
	if(strlen($submitFile)>0)
	{
		$dir = 'files/';

		$file = $dir.basename($_FILES[fileNPCList][name]);
		$strRet .=  "<div align=center><b>Moving file to :".$file."</b></div>";
		if (move_uploaded_file($_FILES[fileNPCList][tmp_name], $file)) 
		{
			$strRet .=  "<div align=center><b>File is valid, and was successfully uploaded.</b></div>";
			$strRet .=  "<div align=center><b>Dropping current character information...</b></div>";
			dropNPCTable();
			$strRet .=  "<div align=center><b>Now reading file into database...</b></div>";
//-------------------------------------------------------------------------------------------
				$data = new Spreadsheet_Excel_Reader();
				$data->setOutputEncoding('CP1251');

				$data->setUTFEncoder('mb');
				/***
				* if you want you can change 'iconv' to mb_convert_encoding:
				* $data->setUTFEncoder('mb');
				*
				**/

				$data->read($file);

				/*
				 $data->sheets[0]['numRows'] - count rows
				 $data->sheets[0]['numCols'] - count columns
				 $data->sheets[0]['cells'][$i][$j] - data from $i-row $j-column
				 $data->sheets[0]['cellsInfo'][$i][$j] - extended info about cell		
					$data->sheets[0]['cellsInfo'][$i][$j]['type'] = "date" | "number" | "unknown"
						if 'type' == "unknown" - use 'raw' value, because  cell contain value with format '0.00';
					$data->sheets[0]['cellsInfo'][$i][$j]['raw'] = value if cell without format 
					$data->sheets[0]['cellsInfo'][$i][$j]['colspan'] 
					$data->sheets[0]['cellsInfo'][$i][$j]['rowspan'] 
				*/

				error_reporting(E_ALL ^ E_NOTICE);
				$count = 0;
				for($k=0;$k<count($data->sheets);$k++)
				{
					for ($i = 1; $i <= $data->sheets[$k]['numRows']; $i++) 
					{
						$count++;
						if($i==1)
						{
							$strRet .=  "<div>Collecting field names ...</div>";
							$arrayFields = '';
							for ($j = 1; $j <= $data->sheets[$k]['numCols']; $j++) 
							{
								$index = $j-1;
								$fieldName = $data->sheets[$k]['cells'][$i][$j];
								$fieldName = strip_tags($fieldName);
								$fieldName = trim($fieldName);
								$fieldName = stripslashes($fieldName);								  
								$fieldName = stripcslashes($fieldName);
								$fieldName = str_replace(' ', '', $fieldName);
								$fieldName = str_replace('.', '_', $fieldName);
								$fieldName = str_replace('/', '_', $fieldName);
	 							$strRet .= $fieldName." ";
								$arrayFields[$index] = $fieldName;
							}
							$strRet .=  "</div>";
							$strRet .=  "<div align=center><b>Creating table...</b></div>";
							createNPCTable($arrayFields);
						}
						else
						{
							$strRet .=  "<div>Reading Character Data : ".$data->sheets[$k]['cells'][$i][1]."</div>";
							$arrayValues = '';
							for ($j = 1; $j <= $data->sheets[$k]['numCols']; $j++) 
							{
								$index = $j-1;
								$arrayValues[$index] = $data->sheets[$k]['cells'][$i][$j];
							}
							if(strlen($arrayValues[0])>0)
								newNPCTableRow($arrayFields, $arrayValues);
						}
					}
				}
			$strRet .=  "<div align=center><b>Total # of characters data read: ".$count."</b></div>";
//-------------------------------------------------------------------------------------------
		}
		else
		{
			$strRet .= "<div align=center>Upload failed. Possible file upload attack!</div>";
		}
	}

	$strRet .= drawSectionText($_SESSION['strSectionID']);

	$strRet .= "<form method=post action='' enctype='multipart/form-data'>";
	$strRet .= "<div><input type='file' name='fileNPCList'></div>";
	$strRet .= "<div>".drawSubmit('submitFile', 'Upload NPC List')."</div>";
	$strRet .= "</form>";

    return '<html><body style="background:#EEEEE7;">'.get_admin_menu().$strRet.'</body></html>';

}

// OUTPUT WEBPAGE	-----------------------------
include(cPathPrefix . '/layout_invis.php');
?>