<?php

	ini_set( 'session.use_cookies', (int)1 );
	ini_set( 'session.use_trans_sid', (int)0 );
	ini_set( 'url_rewriter.tags', '' );

	session_start();
	header('Cache-control:private');

	// turn on buffering
	if (ob_get_level() == 0)
		ob_start();	

// **************************************************
// ***** Rendering/Construction Functions (called by Layout)
// **************************************************

function do_setup()
{
	// **************************************************
	// * Name: do_setup
	// * Purpose: Initialize the page and its State
	// * Return: [none]
	// * Depends: Set State values for current Section, parent Section, navigation info
	// **************************************************
	$cFunctionName = 'do_setup';
	global $aState, $aConfig, $aModule, $aOptions;

	perf_Push($cFunctionName . ' - begin', cCaptureLevelMajor);

	//---------------------------------------------------------------------
	// Validate the browser session to avoid bad mojo in access rates
	//---------------------------------------------------------------------
	validateBrowserSession();

	//---------------------------------------------------------------------
	// authenticate user by cookie, and set intUserID in aState, 
	// now we know who they are - even if a guest
	//---------------------------------------------------------------------
    
	getUserInfo();	// NOTE: This will set iniatial User Data see below:

	//---------------------------------------------------------------------
	// Figure out where we are and pregenerate what we need
	//---------------------------------------------------------------------
	$_SESSION['strSectionID']		= cleanPath($_SERVER['PHP_SELF'], $aConfig['strAppPrefix'], $aModule['strAppPrefix']);
	$aState['strSectionID'] = $_SESSION['strSectionID'];
	$thisSection 				= getSection($_SESSION['strSectionID']);

	// Loop for each field value and set them ALL in sessions and State
	while($stat = mysql_fetch_assoc($thisSection))
	{
		$statExclude = array('');							// Exclude the ones REALLY not needed.
		$keys = array_keys($stat);
		for($i=0;$i<count($keys);$i++)
		{													// Copy ALL user information over into session
			$keyName = $keys[$i];	
			if(! in_array($keyName, $statExclude) ) 
			{
				setSession($keyName, $stat[$keyName]);			
				$aState[$keyName]	= $stat[$keyName];
			}
		}
	}
	//---------------------------------------------------------------------

	perf_Push($cFunctionName . ' - end', cCaptureLevelMajor);

	global $blnHTMLArea;
	$blnEditThisText = getRequest(blnEditThisText);
		if(strlen($blnEditThisText)>0)
			$blnHTMLArea=1;
}

function do_cleanup()
{
	// **************************************************
	// * Name: do_cleanup
	// * Purpose: Page clean-up/termination
	// * Return: [none]
	// * Depends: Closes any open connections
	// **************************************************

	$cFunctionName = 'do_cleanup';
	global $aConfig, $aState;

//	$strRet .= "<hr>";
//	print_r($_SESSION);
//	$strRet .= "<hr>";
	perf_Push($cFunctionName, cCaptureLevelMajor);
//	perf_dump();

	// clean up
	if (is_resource($aConfig['conn']))
	{
		// close the conn
		closeConn($aConfig['conn']);
	}

	if ( cBlnTrackUsage == 1 )
		trackLinkTo();

	$aState		= '';
	$aConfig	= '';
	$aMetric	= '';
}

define('cCorePrefix', cPathPrefix.'/core');

include(cPathPrefix . '/include/common.php');
perf_Push('post include', cCaptureLevelMajor);

do_setup();

$_SESSION['strViewPermission'] = 'guestPower';
$_SESSION['strEditorPermission'] = 'adminPower';
$_SESSION['strManagerPermission'] = 'adminPower';
$_SESSION['strContentPermission'] = 'adminPower';
 
ob_clean();
//print '<html><body style="background:#EEEEE7;">'.do_content('').'</body></html>'; 
print do_content(''); 

do_cleanup();
?>